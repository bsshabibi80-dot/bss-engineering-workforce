# BUILD 18 — PRODUCTION PPM WIRING

Activated foundations:
- Supabase Storage bucket `ppm-photos`
- Storage upload helper
- start_ppm_execution RPC
- complete_ppm_execution RPC
- approve_ppm_execution RPC
- PPM audit trail
- Mobile execution page wired to Supabase RPC/table/storage
- Photo metadata insert

Deployment:
1. Apply migrations 013–018 in order.
2. Confirm `ppm_schedule`, `employees`, `equipment` schema.
3. Configure Supabase Auth users and employee.user_id.
4. Test storage policies with authenticated account.
5. Test one PPM from schedule to QC.
6. Recalculate KPI after APPROVED execution using KPI engine.
