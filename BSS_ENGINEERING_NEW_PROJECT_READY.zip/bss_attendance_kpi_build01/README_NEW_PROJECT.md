# BSS ENGINEERING WORKFORCE MANAGEMENT SYSTEM

Mobile-first engineering workforce, attendance, PPM, complaint, work order and KPI application.

## Four sites
- Palmerah
- Pecenongan
- Sangaji
- Permata Hijau

## Roles
- SUPER_ADMIN
- ADMIN/MANAGER
- SUPERVISOR
- ENGINEER/TECHNICIAN

## Main flow
Attendance -> PPM -> Complaint/WO -> QC -> KPI -> Reports

## Deployment
Upload this project to GitHub, import the repository into Vercel, create a Supabase project, apply migrations 007-021, and configure the two public Supabase environment variables.

See `PROJECT_NEW_SETUP.md` and `FINAL_RELEASE_RUNBOOK_BUILD21.md`.
