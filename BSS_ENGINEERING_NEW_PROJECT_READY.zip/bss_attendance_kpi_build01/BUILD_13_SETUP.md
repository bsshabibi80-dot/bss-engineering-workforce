# BUILD 13 — IMPORT PPM BULANAN

## Tujuan
Memasukkan data PPM satu bulan sekaligus dari file, lalu menjadikannya PPM Schedule.

## Alur
Upload -> Preview -> Validation -> Confirm -> Database -> PPM KPI.

## Data wajib
tanggal_ppm, gedung, equipment_id, jenis_ppm, teknisi, status.

## Prinsip
- Histori bulan sebelumnya tidak dihapus.
- Data duplikat harus ditolak oleh unique equipment/date.
- Data salah harus terlihat sebelum konfirmasi.
- Template CSV disediakan untuk pengujian ringan di HP.
- Build 14 akan menambahkan parser XLSX nyata, transaksi server, dan export.
