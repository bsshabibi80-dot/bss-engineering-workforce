# BUILD 05 — PPM-CENTRIC KPI

Sistem sekarang menjadikan **Preventive Maintenance sebagai dasar KPI** dan menghubungkan:
Equipment → PPM → Complaint → Breakdown → Repeat Complaint → Technician → Building KPI.

## KPI GEDUNG
- PPM Achievement: 30%
- Complaint: 30%
- Repeat Complaint: 15%
- SLA Response/Resolution: 15%
- Equipment Availability: 10%

## KPI KARYAWAN
- PPM Execution: 25%
- Complaint Impact: 25%
- Quality / Repeat Job: 20%
- Response / Resolution: 10%
- Attendance / Discipline: 10%
- Safety / SOP: 10%

## Complaint severity
Minor=1, Medium=3, Major=7, Critical=15.

Komplain tidak otomatis menjadi kesalahan teknisi. Sistem menghubungkan complaint dengan equipment, PPM terakhir, assigned technician, root cause dan QC. Penurunan KPI karyawan harus dilakukan bila ada hubungan yang dapat dipertanggungjawabkan, misalnya missed PPM, checklist tidak sesuai, rework atau repeat complaint yang terkait pekerjaan teknisi.

## Repeat Complaint
Default window 30 hari. Dapat diubah menjadi 7/14/30/60/90 hari sesuai jenis equipment.

## Next
BUILD 06 akan membuat dashboard realtime supervisor/admin, drill-down 4 gedung, ranking teknisi, complaint heatmap, PPM due/overdue, repeat complaint, QC approval, dan export report.
