const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const required=[
'app/page.js','app/login/page.js','app/attendance/page.js','app/attendance-monitor/page.js',
'app/ppm/page.js','app/ppm-import/page.js','app/ppm-execution/page.js','app/ppm-schedule/page.js',
'app/ppm-qc/page.js','app/complaint/page.js','app/work-orders/page.js','app/kpi/page.js',
'app/management/page.js','app/reports/page.js','app/operations/page.js','lib/supabase-browser.js'
];
let fail=0;
for(const f of required){if(!fs.existsSync(path.join(root,f))){console.error('MISSING',f);fail++;}else console.log('OK',f)}
const helper=fs.readFileSync(path.join(root,'lib/supabase-browser.js'),'utf8');
if(!helper.includes('export const supabase')){console.error('FAIL supabase singleton');fail++} else console.log('OK supabase singleton');
const mig=fs.readdirSync(path.join(root,'supabase/migrations')).filter(x=>/^0(0[1-9]|1[0-9]|2[0-1])_/.test(x));
console.log('Migrations found:',mig.length);
console.log(fail?'PREFLIGHT FAILED':'PREFLIGHT PASSED');
process.exit(fail?1:0);
