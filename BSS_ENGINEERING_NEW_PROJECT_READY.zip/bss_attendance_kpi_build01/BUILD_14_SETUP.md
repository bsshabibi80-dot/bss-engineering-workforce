# BUILD 14 — REAL XLSX PPM IMPORT

Fitur:
- Import .xlsx/.xls langsung dari HP
- Preview maksimal 300 baris
- Validasi kolom wajib, tanggal, gedung, duplikat
- Template Excel otomatis
- Batch import dan audit metadata
- RPC Supabase transaction foundation
- Equipment & teknisi mapping di sisi server
- Histori bulanan tidak dihapus

Catatan deployment:
1. npm install
2. npm run build
3. Jalankan migration 013 dan 014 di Supabase.
4. Pastikan master equipment dan employees sudah lengkap.
5. Hubungkan tombol Konfirmasi ke RPC import_ppm_batch.
6. Untuk production, gunakan service/RLS yang sesuai dan audit log.
