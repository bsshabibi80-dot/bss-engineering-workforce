# REGRESSION CHECK BUILD 19
[x] Attendance foundation retained
[x] QR/GPS retained
[x] Complaint retained
[x] Work Order retained
[x] KPI dashboard retained
[x] XLSX PPM import retained
[x] PPM schedule retained
[x] PPM execution retained
[x] PPM photo storage wiring retained
[x] QC approval/rejection added
[x] Management dashboard added
[x] KPI refresh queue added
[ ] Live Supabase migration verification
[ ] Edge/server worker for KPI queue
[ ] Production Android test
[ ] Real building/equipment master-data validation
