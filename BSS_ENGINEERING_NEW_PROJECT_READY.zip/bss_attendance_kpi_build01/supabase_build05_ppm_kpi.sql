-- BSS ENGINEERING BUILD 05
-- PPM-centric Building KPI + Employee KPI + Complaint/Breakdown + Repeat Complaint

create table if not exists complaint_categories (
  code text primary key,
  name text not null,
  severity_points numeric(8,2) not null
);

insert into complaint_categories(code,name,severity_points) values
('MINOR','Minor',1),('MEDIUM','Medium',3),('MAJOR','Major',7),('CRITICAL','Critical',15)
on conflict(code) do update set name=excluded.name,severity_points=excluded.severity_points;

create table if not exists complaints (
  id uuid primary key default gen_random_uuid(),
  ticket_no text unique not null,
  building_code text not null,
  floor text,
  equipment_code text,
  category_code text references complaint_categories(code),
  title text not null,
  description text,
  reported_at timestamptz not null default now(),
  acknowledged_at timestamptz,
  resolved_at timestamptz,
  assigned_to uuid,
  root_cause text,
  corrective_action text,
  source text not null default 'TENANT',
  status text not null default 'OPEN',
  severity_points numeric(8,2) not null default 1,
  repeat_flag boolean not null default false,
  repeat_window_days integer not null default 30,
  created_at timestamptz not null default now()
);

create index if not exists idx_complaint_building on complaints(building_code,reported_at);
create index if not exists idx_complaint_equipment on complaints(equipment_code,reported_at);
create index if not exists idx_complaint_assignee on complaints(assigned_to,status);

-- Equipment master allows PPM, complaint and breakdown history to meet on one asset.
create table if not exists equipment_master (
  id uuid primary key default gen_random_uuid(),
  building_code text not null,
  floor text,
  equipment_code text not null unique,
  equipment_type text not null,
  description text,
  criticality text not null default 'NORMAL',
  active boolean not null default true
);

create table if not exists ppm_schedule (
  id uuid primary key default gen_random_uuid(),
  equipment_id uuid references equipment_master(id),
  building_code text not null,
  period_month date not null,
  planned_date date,
  completed_date date,
  assigned_to uuid,
  status text not null default 'PLANNED',
  checklist_score numeric(5,2),
  qc_score numeric(5,2),
  overdue_days integer default 0
);

create index if not exists idx_ppm_period on ppm_schedule(building_code,period_month,status);

-- Repeat complaint: same equipment within repeat_window_days after previous resolution.
create or replace function flag_repeat_complaint()
returns trigger language plpgsql as $$
begin
  if new.equipment_code is not null then
    if exists (
      select 1 from complaints old
      where old.id <> new.id
        and old.equipment_code = new.equipment_code
        and old.resolved_at is not null
        and new.reported_at >= old.resolved_at
        and new.reported_at <= old.resolved_at + make_interval(days => new.repeat_window_days)
    ) then
      new.repeat_flag := true;
    end if;
  end if;
  return new;
end $$;

drop trigger if exists trg_repeat_complaint on complaints;
create trigger trg_repeat_complaint
before insert or update of equipment_code,reported_at,repeat_window_days
on complaints for each row execute function flag_repeat_complaint();

-- Building KPI component function.
-- Complaint score is normalized against a monthly target; lower complaint burden = higher score.
create or replace function complaint_score(total_severity_points numeric, target_points numeric)
returns numeric language sql immutable as $$
  select case when coalesce(target_points,0) <= 0 then 100
       else greatest(0, least(100, 100 - (coalesce(total_severity_points,0) / target_points * 100)))
  end
$$;

-- PPM achievement score.
create or replace function ppm_achievement_score(completed_count numeric, planned_count numeric)
returns numeric language sql immutable as $$
  select case when coalesce(planned_count,0) <= 0 then 100
       else least(100, greatest(0, completed_count/planned_count*100))
  end
$$;

-- Example building KPI: PPM 30, Complaint 30, Repeat 15, SLA 15, Availability 10.
create table if not exists building_kpi_monthly (
  id uuid primary key default gen_random_uuid(),
  building_code text not null,
  period_month date not null,
  ppm_score numeric(5,2) default 0,
  complaint_score numeric(5,2) default 0,
  repeat_complaint_score numeric(5,2) default 0,
  sla_score numeric(5,2) default 0,
  availability_score numeric(5,2) default 0,
  final_score numeric(5,2) generated always as (
    ppm_score*.30 +
    complaint_score*.30 +
    repeat_complaint_score*.15 +
    sla_score*.15 +
    availability_score*.10
  ) stored,
  unique(building_code,period_month)
);

-- Employee KPI PPM-centric:
-- PPM execution 25, complaint impact 25, quality/repeat 20, response/resolution 10,
-- attendance/discipline 10, safety/SOP 10.
create table if not exists employee_kpi_monthly (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null,
  building_code text,
  period_month date not null,
  ppm_score numeric(5,2) default 0,
  complaint_score numeric(5,2) default 0,
  quality_score numeric(5,2) default 0,
  response_score numeric(5,2) default 0,
  attendance_discipline_score numeric(5,2) default 0,
  safety_sop_score numeric(5,2) default 0,
  final_score numeric(5,2) generated always as (
    ppm_score*.25 +
    complaint_score*.25 +
    quality_score*.20 +
    response_score*.10 +
    attendance_discipline_score*.10 +
    safety_sop_score*.10
  ) stored,
  grade text,
  unique(employee_id,period_month)
);
