# BUILD 15 — FLEXIBLE XLSX + ATOMIC COMMIT

## Tambahan
- Header Excel tidak harus persis sama.
- Alias diterima: Tanggal/Tgl, Gedung/Site, Equipment/Kode Asset, Teknisi/Technician, dll.
- Preview mapping kolom sebelum import.
- Commit database memakai RPC transaction-style.
- Duplicate equipment + tanggal dilewati oleh unique index.
- Batch diberi status IMPORTED setelah commit.

## Production check
- Cocokkan nama kolom ppm_schedule dengan schema Supabase aktif.
- Hubungkan tombol konfirmasi UI ke `commit_ppm_import(batch_id)`.
- Isi master equipment dan employees.
- Test 1 bulan kecil, lalu 1 bulan penuh.
