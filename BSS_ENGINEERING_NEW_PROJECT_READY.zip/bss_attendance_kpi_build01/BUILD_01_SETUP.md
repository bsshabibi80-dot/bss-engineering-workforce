# BSS Engineering Attendance & KPI — BUILD 01

## Admin
- Email: bsshabibi80@gmail.com
- Role: SUPER_ADMIN
- Full application permissions: read/create/edit/delete/export/manage.

## Buildings
- Palmerah (PAL)
- Pecenongan (PEC)
- Sangaji (SAN)
- Permata Hijau (PH)

## Important
The admin email is an identity/role setting only. Do NOT put a Supabase password,
service-role key, or other secret in the frontend source code.

## Production architecture
Next.js + Supabase Auth/PostgreSQL/Realtime + Vercel.

## Security
- Server-side timestamp
- Server-side geofence calculation
- Dynamic QR tokens
- GPS accuracy validation
- Audit logs
- Role-based access control (RBAC)

## Build sequence
01 Login + users + buildings
02 QR + GPS + attendance
03 Work orders + checklists
04 KPI engine
05 Supervisor/manager dashboards
06 Excel/PDF reporting
07 PWA/offline/notifications
08 Full regression/security test
