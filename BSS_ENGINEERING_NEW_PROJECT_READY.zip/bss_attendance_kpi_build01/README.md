# BSS Engineering Attendance & KPI — Prototype

Prototype mobile-first PWA untuk pengujian alur: dashboard, QR check-in, GPS permission, checkout, work order sederhana, KPI, profil dan local storage.

## Uji cepat
1. Buka `index.html` melalui browser modern. Untuk kamera/GPS, gunakan HTTPS/localhost.
2. Pilih lokasi pada Profil.
3. Scan/masukkan salah satu demo QR: `QR-PAL-001`, `QR-PEC-001`, `QR-SAN-001`, `QR-PH-001`.
4. Izinkan kamera dan lokasi.
5. Coba Task dan KPI.

## Produksi yang perlu ditambahkan
- Supabase Auth/PostgreSQL/Realtime
- QR dinamis bertanda tangan dan expiry
- Geofence server-side dan anti-spoof rules
- Role Admin/Supervisor/Employee
- Work order terintegrasi
- KPI engine berbobot + approval
- Excel/PDF export
- Push notification
- Audit log dan device binding
- Offline queue dengan sinkronisasi aman
- Backup dan RLS database
