# BSS ENGINEERING — NEW PROJECT

Project name:
BSS Engineering Workforce Management System

Suggested production services:
- GitHub: repository `bss-engineering-workforce`
- Vercel: project `bss-engineering-workforce`
- Supabase: project `bss-engineering-workforce`

Admin identity:
bsshabibi80@gmail.com

IMPORTANT:
This package is ready to be uploaded to a new GitHub repository and connected to Vercel/Supabase.
A live URL cannot be created from this chat because this workspace does not have access to your GitHub/Vercel/Supabase accounts.

Do not put Supabase service-role keys in the browser or repository.
Only NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY belong in Vercel public environment variables.

Recommended first UAT:
1. Admin login.
2. Create four buildings.
3. Create one test employee.
4. Create one equipment item.
5. Import one PPM.
6. Run PPM from mobile.
7. Upload photo.
8. Complete and QC.
9. Verify KPI.
10. Test QR/GPS attendance.
11. Test complaint -> WO -> QC.
12. Export report.
