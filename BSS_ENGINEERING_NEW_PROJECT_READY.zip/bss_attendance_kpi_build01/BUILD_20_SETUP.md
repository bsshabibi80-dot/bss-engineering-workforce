# BUILD 20 — PRODUCTION ENGINE
Added:
- KPI refresh queue processor foundation
- Notification queue foundation
- Management summary view
- Mobile reporting page
- CSV export from real Supabase rows
- Preserves BUILD 01–19

Important production boundary:
- The queue processor is a safe server-side foundation but is not a hosted cron/Edge Worker until deployed in Supabase.
- Browser CSV export is active; XLSX/PDF should be connected to the existing XLSX/PDF libraries/endpoints in the deployment environment.
- Push notification delivery needs FCM/Web Push credentials and a server-side sender.
