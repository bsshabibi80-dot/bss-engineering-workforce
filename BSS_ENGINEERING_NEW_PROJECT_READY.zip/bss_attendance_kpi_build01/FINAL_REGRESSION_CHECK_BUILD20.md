# FINAL REGRESSION CHECK BUILD 20

CORE
[x] Dashboard
[x] Mobile responsive UI
[x] Login foundation
[x] 4 buildings
[x] Admin/SUPER_ADMIN foundation
[x] Attendance
[x] QR
[x] GPS/geofence foundation
[x] Audit log

ENGINEERING
[x] Equipment
[x] PPM Schedule
[x] PPM XLSX import
[x] PPM assignment
[x] PPM execution
[x] Checklist
[x] Photo Storage foundation
[x] Complaint
[x] Work Order
[x] QC
[x] Repeat complaint foundation

KPI
[x] Building KPI model
[x] Employee KPI model
[x] KPI dashboard
[x] KPI refresh queue foundation
[x] Management summary

REPORTING
[x] Reports page
[x] CSV export
[ ] Live XLSX export verification
[ ] Live PDF export verification

PRODUCTION
[x] Storage policy foundation
[x] RLS foundations
[x] Notification queue foundation
[ ] Supabase production migration execution
[ ] KPI scheduled worker deployment
[ ] Push notification sender deployment
[ ] Real master data
[ ] Building coordinates
[ ] Android field test
[ ] Load/security test
