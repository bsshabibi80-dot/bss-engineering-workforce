
-- BUILD 11: KPI engine
create table if not exists public.kpi_monthly (
 id uuid primary key default gen_random_uuid(),
 period_month date not null,
 building_code text references public.buildings(code),
 employee_id uuid references public.employees(id),
 ppm_achievement numeric(6,2) default 0,
 complaint_score numeric(6,2) default 0,
 repeat_complaint_score numeric(6,2) default 0,
 sla_score numeric(6,2) default 0,
 availability_score numeric(6,2) default 0,
 ppm_execution_score numeric(6,2) default 0,
 complaint_impact_score numeric(6,2) default 0,
 quality_repeat_job_score numeric(6,2) default 0,
 response_resolution_score numeric(6,2) default 0,
 attendance_discipline_score numeric(6,2) default 0,
 safety_sop_score numeric(6,2) default 0,
 building_kpi numeric(6,2) default 0,
 employee_kpi numeric(6,2) default 0,
 grade text,
 calculated_at timestamptz default now(),
 unique(period_month, building_code, employee_id)
);

create index if not exists idx_kpi_monthly_period on public.kpi_monthly(period_month);
create index if not exists idx_kpi_monthly_building on public.kpi_monthly(building_code);

create or replace function public.calculate_building_kpi(
 p_ppm numeric,p_complaint numeric,p_repeat numeric,p_sla numeric,p_availability numeric
) returns numeric language sql immutable as $$
 select round(
  greatest(0,least(100,p_ppm))*0.30 +
  greatest(0,least(100,p_complaint))*0.30 +
  greatest(0,least(100,p_repeat))*0.15 +
  greatest(0,least(100,p_sla))*0.15 +
  greatest(0,least(100,p_availability))*0.10,2)
$$;

create or replace function public.calculate_employee_kpi(
 p_ppm numeric,p_complaint numeric,p_quality numeric,p_response numeric,p_attendance numeric,p_safety numeric
) returns numeric language sql immutable as $$
 select round(
  greatest(0,least(100,p_ppm))*0.25 +
  greatest(0,least(100,p_complaint))*0.25 +
  greatest(0,least(100,p_quality))*0.20 +
  greatest(0,least(100,p_response))*0.10 +
  greatest(0,least(100,p_attendance))*0.10 +
  greatest(0,least(100,p_safety))*0.10,2)
$$;

alter table public.kpi_monthly enable row level security;
create policy "authenticated read kpi" on public.kpi_monthly for select to authenticated using (true);
create policy "managers manage kpi" on public.kpi_monthly for all to authenticated
using (public.can_manage_engineering()) with check (public.can_manage_engineering());
