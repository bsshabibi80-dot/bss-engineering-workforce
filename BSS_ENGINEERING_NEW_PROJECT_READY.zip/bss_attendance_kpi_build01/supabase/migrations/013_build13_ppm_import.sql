
-- BUILD 13: monthly PPM import foundation
create table if not exists public.ppm_import_batches (
 id uuid primary key default gen_random_uuid(),
 period_month date not null,
 file_name text not null,
 imported_by uuid,
 total_rows integer not null default 0,
 valid_rows integer not null default 0,
 error_rows integer not null default 0,
 duplicate_rows integer not null default 0,
 status text not null default 'UPLOADED',
 created_at timestamptz not null default now()
);

create table if not exists public.ppm_import_rows (
 id uuid primary key default gen_random_uuid(),
 batch_id uuid not null references public.ppm_import_batches(id) on delete cascade,
 row_number integer not null,
 ppm_date date,
 building_code text,
 equipment_code text,
 equipment_name text,
 location text,
 ppm_type text,
 frequency text,
 technician_name text,
 shift_name text,
 status text,
 target numeric default 1,
 notes text,
 validation_status text not null default 'PENDING',
 validation_message text,
 created_at timestamptz not null default now()
);

create index if not exists idx_ppm_import_batch on public.ppm_import_rows(batch_id);
create index if not exists idx_ppm_import_period on public.ppm_import_batches(period_month);

alter table public.ppm_import_batches enable row level security;
alter table public.ppm_import_rows enable row level security;

create policy "managers read ppm imports" on public.ppm_import_batches for select to authenticated
using (public.can_manage_engineering());
create policy "managers insert ppm imports" on public.ppm_import_batches for insert to authenticated
with check (public.can_manage_engineering());

create policy "managers read ppm import rows" on public.ppm_import_rows for select to authenticated
using (public.can_manage_engineering());
create policy "managers insert ppm import rows" on public.ppm_import_rows for insert to authenticated
with check (public.can_manage_engineering());

-- Prevent duplicate monthly schedule for the same equipment/date when source schedule exists.
create unique index if not exists uq_ppm_schedule_equipment_date
on public.ppm_schedule(equipment_id, scheduled_date);
