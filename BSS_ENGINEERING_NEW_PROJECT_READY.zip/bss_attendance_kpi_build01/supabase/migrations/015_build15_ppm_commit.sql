
-- BUILD 15: atomic commit for validated PPM imports
create or replace function public.commit_ppm_import(p_batch_id uuid)
returns jsonb language plpgsql security definer
set search_path=public
as $$
declare
 r record; v_inserted int:=0; v_skipped int:=0;
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if not exists(select 1 from public.ppm_import_batches where id=p_batch_id and status in ('VALIDATED','REVIEW')) then
   raise exception 'INVALID_BATCH';
 end if;

 for r in
   select ir.*, e.id equipment_uuid
   from public.ppm_import_rows ir
   left join public.equipment e on e.equipment_code=ir.equipment_code
   where ir.batch_id=p_batch_id and ir.validation_status='READY'
   order by ir.row_number
 loop
   if r.equipment_uuid is null then
     v_skipped:=v_skipped+1; continue;
   end if;
   begin
     insert into public.ppm_schedule(equipment_id,scheduled_date,status,notes)
     values(r.equipment_uuid,r.ppm_date,coalesce(nullif(r.status,''),'SCHEDULED'),r.notes)
     on conflict (equipment_id,scheduled_date) do nothing;
     if found then v_inserted:=v_inserted+1; else v_skipped:=v_skipped+1; end if;
   exception when undefined_column or undefined_table then
     raise exception 'PPM_SCHEDULE_SCHEMA_MISMATCH: sesuaikan kolom ppm_schedule dengan schema aktif';
   end;
 end loop;

 update public.ppm_import_batches
 set status='IMPORTED', valid_rows=v_inserted, duplicate_rows=v_skipped
 where id=p_batch_id;

 return jsonb_build_object('batch_id',p_batch_id,'inserted',v_inserted,'skipped',v_skipped);
end $$;
