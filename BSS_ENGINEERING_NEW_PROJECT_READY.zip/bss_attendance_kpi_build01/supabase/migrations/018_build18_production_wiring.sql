
-- BUILD 18: production wiring for PPM execution, photos, QC, KPI and audit
insert into storage.buckets (id,name,public)
values ('ppm-photos','ppm-photos',false)
on conflict (id) do update set public=false;

create policy "ppm photos upload own" on storage.objects
for insert to authenticated
with check (bucket_id='ppm-photos' and auth.uid() is not null);

create policy "ppm photos read authorized" on storage.objects
for select to authenticated
using (bucket_id='ppm-photos' and auth.uid() is not null);

create table if not exists public.ppm_audit_events (
 id uuid primary key default gen_random_uuid(),
 ppm_schedule_id uuid,
 execution_id uuid,
 action text not null,
 actor_id uuid references auth.users(id),
 detail jsonb default '{}'::jsonb,
 created_at timestamptz not null default now()
);
alter table public.ppm_audit_events enable row level security;
create policy "ppm audit read managers" on public.ppm_audit_events
for select to authenticated using (public.can_manage_engineering());

create or replace function public.start_ppm_execution(p_schedule_id uuid)
returns uuid language plpgsql security definer set search_path=public
as $$
declare v_employee uuid; v_execution uuid;
begin
 select id into v_employee from public.employees where user_id=auth.uid() and active=true limit 1;
 if v_employee is null then raise exception 'EMPLOYEE_NOT_FOUND'; end if;
 if not exists(select 1 from public.ppm_assignments where ppm_schedule_id=p_schedule_id and employee_id=v_employee and status='ASSIGNED')
    and not public.can_manage_engineering() then raise exception 'NOT_ASSIGNED'; end if;

 select id into v_execution from public.ppm_execution_steps
 where ppm_schedule_id=p_schedule_id and employee_id=v_employee
 order by created_at desc limit 1;

 if v_execution is null then
   insert into public.ppm_execution_steps(ppm_schedule_id,employee_id,started_at,qc_status)
   values(p_schedule_id,v_employee,now(),'PENDING') returning id into v_execution;
 end if;

 update public.ppm_schedule set status='IN_PROGRESS' where id=p_schedule_id and status in ('SCHEDULED','ASSIGNED');

 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id)
 values(p_schedule_id,v_execution,'START',auth.uid());

 return v_execution;
end $$;

create or replace function public.complete_ppm_execution(p_execution_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare e public.ppm_execution_steps%rowtype;
begin
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;
 if e.employee_id is distinct from (select id from public.employees where user_id=auth.uid())
    and not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if coalesce(jsonb_array_length(e.checklist),0)=0 then raise exception 'CHECKLIST_REQUIRED'; end if;

 update public.ppm_execution_steps set completed_at=coalesce(completed_at,now()), qc_status='PENDING' where id=p_execution_id;
 update public.ppm_schedule set status='COMPLETED' where id=e.ppm_schedule_id;

 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id)
 values(e.ppm_schedule_id,e.id,'COMPLETE',auth.uid());

 return jsonb_build_object('ok',true,'execution_id',p_execution_id,'completed_at',now());
end $$;

create or replace function public.approve_ppm_execution(p_execution_id uuid,p_qc_status text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare e public.ppm_execution_steps%rowtype;
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if p_qc_status not in ('APPROVED','REJECTED') then raise exception 'INVALID_QC_STATUS'; end if;
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;

 update public.ppm_execution_steps
 set qc_status=p_qc_status,qc_by=auth.uid(),qc_at=now()
 where id=p_execution_id;

 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id,detail)
 values(e.ppm_schedule_id,e.id,'QC_'||p_qc_status,auth.uid(),jsonb_build_object('note',p_note));

 -- KPI refresh is intentionally idempotent: the KPI engine can recalculate from approved executions.
 return jsonb_build_object('ok',true,'execution_id',p_execution_id,'qc_status',p_qc_status,'kpi_refresh_required',true);
end $$;
