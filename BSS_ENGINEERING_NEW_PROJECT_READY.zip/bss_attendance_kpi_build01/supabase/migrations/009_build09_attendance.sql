
-- BUILD 09: secure attendance / QR / GPS foundation
create table if not exists public.shifts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  start_time time not null,
  end_time time not null,
  late_tolerance_min integer not null default 10,
  active boolean not null default true
);

create table if not exists public.qr_locations (
  id uuid primary key default gen_random_uuid(),
  building_code text not null references public.buildings(code),
  label text not null,
  secret_hash text not null,
  rotation_seconds integer not null default 60,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id),
  building_code text not null references public.buildings(code),
  shift_id uuid references public.shifts(id),
  work_date date not null default current_date,
  check_in_at timestamptz,
  check_out_at timestamptz,
  check_in_lat double precision,
  check_in_lng double precision,
  check_in_accuracy_m double precision,
  check_out_lat double precision,
  check_out_lng double precision,
  check_out_accuracy_m double precision,
  check_in_qr_id uuid references public.qr_locations(id),
  check_out_qr_id uuid references public.qr_locations(id),
  status text not null default 'PRESENT',
  validation_status text not null default 'PENDING',
  validation_note text,
  total_minutes integer,
  created_at timestamptz not null default now(),
  unique(employee_id, work_date)
);

create table if not exists public.attendance_logs (
  id uuid primary key default gen_random_uuid(),
  attendance_id uuid references public.attendance(id) on delete cascade,
  employee_id uuid references public.employees(id),
  action text not null,
  server_at timestamptz not null default now(),
  device_lat double precision,
  device_lng double precision,
  device_accuracy_m double precision,
  qr_location_id uuid references public.qr_locations(id),
  distance_m double precision,
  result text not null,
  note text
);

insert into public.shifts(name,start_time,end_time,late_tolerance_min)
values ('Engineering Regular','08:00','17:00',10)
on conflict do nothing;

-- Server-side distance helper.
create or replace function public.haversine_m(lat1 double precision,lng1 double precision,lat2 double precision,lng2 double precision)
returns double precision language sql immutable as $$
  select 6371000 * 2 * asin(sqrt(
    power(sin(radians(lat2-lat1)/2),2) +
    cos(radians(lat1))*cos(radians(lat2))*power(sin(radians(lng2-lng1)/2),2)
  ))
$$;

-- Validation function: server time + QR building + coordinates + radius + GPS accuracy.
create or replace function public.validate_attendance(
  p_employee_id uuid,
  p_building_code text,
  p_qr_id uuid,
  p_lat double precision,
  p_lng double precision,
  p_accuracy_m double precision
)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  b public.buildings%rowtype;
  q public.qr_locations%rowtype;
  d double precision;
begin
  select * into b from public.buildings where code=p_building_code and active=true;
  if not found then return jsonb_build_object('ok',false,'reason','BUILDING_INVALID'); end if;

  select * into q from public.qr_locations where id=p_qr_id and active=true;
  if not found or q.building_code<>p_building_code then
    return jsonb_build_object('ok',false,'reason','QR_INVALID');
  end if;

  if b.latitude is null or b.longitude is null then
    return jsonb_build_object('ok',false,'reason','BUILDING_COORDINATES_NOT_SET');
  end if;

  if p_accuracy_m is null or p_accuracy_m > 100 then
    return jsonb_build_object('ok',false,'reason','GPS_ACCURACY_TOO_LOW');
  end if;

  d := public.haversine_m(b.latitude,b.longitude,p_lat,p_lng);

  if d > b.geofence_radius_m then
    return jsonb_build_object('ok',false,'reason','OUTSIDE_GEOFENCE','distance_m',round(d::numeric,1),'radius_m',b.geofence_radius_m);
  end if;

  return jsonb_build_object('ok',true,'reason','VALID','distance_m',round(d::numeric,1),'radius_m',b.geofence_radius_m,'server_at',now());
end $$;

alter table public.shifts enable row level security;
alter table public.qr_locations enable row level security;
alter table public.attendance enable row level security;
alter table public.attendance_logs enable row level security;

create policy "authenticated read shifts" on public.shifts for select to authenticated using (true);
create policy "managers manage shifts" on public.shifts for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read qr" on public.qr_locations for select to authenticated using (true);
create policy "managers manage qr" on public.qr_locations for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "employees read own attendance" on public.attendance for select to authenticated
using (employee_id=auth.uid() or public.can_manage_engineering());

create policy "employees insert attendance" on public.attendance for insert to authenticated
with check (employee_id=auth.uid() or public.can_manage_engineering());

create policy "employees update own attendance" on public.attendance for update to authenticated
using (employee_id=auth.uid() or public.can_manage_engineering())
with check (employee_id=auth.uid() or public.can_manage_engineering());

create policy "authenticated read attendance logs" on public.attendance_logs for select to authenticated
using (employee_id=auth.uid() or public.can_manage_engineering());

create policy "authenticated insert attendance logs" on public.attendance_logs for insert to authenticated
with check (employee_id=auth.uid() or public.can_manage_engineering());
