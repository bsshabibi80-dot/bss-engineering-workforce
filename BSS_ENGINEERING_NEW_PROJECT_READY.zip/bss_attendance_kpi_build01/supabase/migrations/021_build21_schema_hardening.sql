
-- BUILD 21: schema hardening discovered during preflight
alter table public.ppm_execution_steps
  add column if not exists qc_note text;

-- PPM schedule historically uses PLANNED/IN_PROGRESS/DONE.
-- Normalize completion to DONE rather than an invalid COMPLETED value.
create or replace function public.complete_ppm_execution(p_execution_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare e public.ppm_execution_steps%rowtype;
begin
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;
 if e.employee_id is distinct from (select id from public.employees where user_id=auth.uid())
    and not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if coalesce(jsonb_array_length(e.checklist),0)=0 then raise exception 'CHECKLIST_REQUIRED'; end if;

 update public.ppm_execution_steps
 set completed_at=coalesce(completed_at,now()), qc_status=coalesce(qc_status,'PENDING')
 where id=p_execution_id;

 update public.ppm_schedule
 set status='DONE', completed_at=coalesce(completed_at,now())
 where id=e.ppm_schedule_id;

 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id)
 values(e.ppm_schedule_id,e.id,'COMPLETE',auth.uid());

 return jsonb_build_object('ok',true,'execution_id',p_execution_id,'completed_at',now());
end $$;

create or replace function public.approve_ppm_execution(p_execution_id uuid,p_qc_status text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare e public.ppm_execution_steps%rowtype;
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if p_qc_status not in ('APPROVED','REJECTED') then raise exception 'INVALID_QC_STATUS'; end if;
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;

 update public.ppm_execution_steps
 set qc_status=p_qc_status,qc_by=auth.uid(),qc_at=now(),qc_note=p_note
 where id=p_execution_id;

 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id,detail)
 values(e.ppm_schedule_id,e.id,'QC_'||p_qc_status,auth.uid(),jsonb_build_object('note',p_note));

 if p_qc_status='APPROVED' then
   insert into public.kpi_refresh_queue(execution_id) values(e.id);
 end if;

 return jsonb_build_object('ok',true,'execution_id',e.id,'qc_status',p_qc_status);
end $$;
