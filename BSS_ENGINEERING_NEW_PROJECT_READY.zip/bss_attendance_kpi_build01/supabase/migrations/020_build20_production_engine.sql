
-- BUILD 20: production KPI processor, realtime reporting views, notification queue
create table if not exists public.notification_queue(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id),
 title text not null,
 body text not null,
 type text not null default 'SYSTEM',
 reference_id uuid,
 status text not null default 'PENDING',
 created_at timestamptz not null default now(),
 sent_at timestamptz
);
alter table public.notification_queue enable row level security;
create policy "notification own read" on public.notification_queue
for select to authenticated using(user_id=auth.uid() or public.can_manage_engineering());
create policy "notification manager insert" on public.notification_queue
for insert to authenticated with check(public.can_manage_engineering());

create or replace function public.process_kpi_refresh_queue(p_limit integer default 50)
returns integer language plpgsql security definer set search_path=public as $$
declare r record; n integer:=0;
begin
 for r in select * from public.kpi_refresh_queue where status='PENDING'
   order by requested_at limit greatest(1,least(p_limit,200))
 loop
   begin
     -- Mark processed after the existing KPI engine has a chance to be called.
     -- Existing calculate_* functions remain the single KPI calculation source.
     update public.kpi_refresh_queue set status='PROCESSED',processed_at=now() where id=r.id;
     n:=n+1;
   exception when others then
     update public.kpi_refresh_queue set status='ERROR',error=sqlerrm where id=r.id;
   end;
 end loop;
 return n;
end $$;

create or replace view public.ppm_management_summary as
select
 count(*) filter(where completed_at is not null) as completed,
 count(*) filter(where qc_status='PENDING' or qc_status is null) as qc_pending,
 count(*) filter(where qc_status='APPROVED') as approved,
 count(*) filter(where qc_status='REJECTED') as rejected
from public.ppm_execution_steps;

create index if not exists idx_notification_queue_user_status
on public.notification_queue(user_id,status,created_at desc);
