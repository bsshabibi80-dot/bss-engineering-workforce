
-- BUILD 17: production-oriented PPM execution
create table if not exists public.ppm_checklist_templates (
 id uuid primary key default gen_random_uuid(),
 equipment_type text not null,
 item_code text not null,
 item_text text not null,
 required boolean not null default true,
 sort_order integer not null default 1,
 active boolean not null default true,
 unique(equipment_type,item_code)
);

create table if not exists public.ppm_execution_photos (
 id uuid primary key default gen_random_uuid(),
 execution_id uuid not null references public.ppm_execution_steps(id) on delete cascade,
 storage_path text not null,
 photo_type text not null default 'AFTER',
 caption text,
 uploaded_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);

alter table public.ppm_checklist_templates enable row level security;
alter table public.ppm_execution_photos enable row level security;
create policy "checklist templates read" on public.ppm_checklist_templates for select to authenticated using (active=true or public.can_manage_engineering());
create policy "checklist templates manage" on public.ppm_checklist_templates for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());
create policy "ppm photos read" on public.ppm_execution_photos for select to authenticated
using (uploaded_by=auth.uid() or public.can_manage_engineering());
create policy "ppm photos insert" on public.ppm_execution_photos for insert to authenticated
with check (uploaded_by=auth.uid() or public.can_manage_engineering());

insert into public.ppm_checklist_templates(equipment_type,item_code,item_text,sort_order)
values
('AC','AC01','Cek kondisi filter dan evaporator',1),
('AC','AC02','Cek drain dan kebocoran',2),
('AC','AC03','Cek arus/tegangan operasi',3),
('AC','AC04','Cek temperatur supply/return',4),
('AC','AC05','Cleaning dan test operation',5),
('PANEL','PN01','Cek kondisi panel dan enclosure',1),
('PANEL','PN02','Cek terminal/koneksi',2),
('PANEL','PN03','Cek arus dan tegangan',3),
('PANEL','PN04','Cek indikator/proteksi',4),
('PANEL','PN05','Cleaning dan thermography bila diperlukan',5),
('PUMP','PM01','Cek kebocoran dan kondisi mekanik',1),
('PUMP','PM02','Cek pressure/flow',2),
('PUMP','PM03','Cek arus motor',3),
('PUMP','PM04','Cek seal/bearing/suara abnormal',4),
('PUMP','PM05','Test operation',5),
('GENSET','GN01','Cek oli, coolant dan fuel',1),
('GENSET','GN02','Cek battery/charger',2),
('GENSET','GN03','Cek tegangan/frekuensi',3),
('GENSET','GN04','Cek kebocoran dan exhaust',4),
('GENSET','GN05','Test load/operation sesuai SOP',5)
on conflict (equipment_type,item_code) do nothing;

-- QC approval + KPI refresh hook
create or replace function public.approve_ppm_execution(p_execution_id uuid,p_qc_status text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if p_qc_status not in ('APPROVED','REJECTED') then raise exception 'INVALID_QC_STATUS'; end if;
 update public.ppm_execution_steps
 set qc_status=p_qc_status,qc_by=auth.uid(),qc_at=now(),
     corrective_action=case when p_note is null then corrective_action else coalesce(corrective_action,'')||E'\nQC: '||p_note end
 where id=p_execution_id;
 if not found then raise exception 'EXECUTION_NOT_FOUND'; end if;
 return jsonb_build_object('ok',true,'execution_id',p_execution_id,'qc_status',p_qc_status);
end $$;
