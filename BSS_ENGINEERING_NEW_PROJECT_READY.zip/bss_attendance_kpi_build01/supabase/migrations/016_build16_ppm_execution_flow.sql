
-- BUILD 16: PPM Schedule -> Assign -> Checklist -> Photo -> Complete -> KPI
create table if not exists public.ppm_assignments (
 id uuid primary key default gen_random_uuid(),
 ppm_schedule_id uuid not null references public.ppm_schedule(id) on delete cascade,
 employee_id uuid not null references public.employees(id),
 assigned_by uuid references auth.users(id),
 assigned_at timestamptz not null default now(),
 status text not null default 'ASSIGNED',
 unique(ppm_schedule_id,employee_id)
);

create table if not exists public.ppm_execution_steps (
 id uuid primary key default gen_random_uuid(),
 ppm_schedule_id uuid not null references public.ppm_schedule(id) on delete cascade,
 employee_id uuid references public.employees(id),
 started_at timestamptz,
 completed_at timestamptz,
 checklist jsonb not null default '[]'::jsonb,
 findings text,
 corrective_action text,
 photo_paths text[] default '{}',
 qc_status text default 'PENDING',
 qc_by uuid references auth.users(id),
 qc_at timestamptz,
 created_at timestamptz not null default now()
);

create index if not exists idx_ppm_assign_schedule on public.ppm_assignments(ppm_schedule_id);
create index if not exists idx_ppm_exec_schedule on public.ppm_execution_steps(ppm_schedule_id);

alter table public.ppm_assignments enable row level security;
alter table public.ppm_execution_steps enable row level security;

create policy "ppm assignment read" on public.ppm_assignments for select to authenticated using (employee_id in (select id from public.employees where user_id=auth.uid()) or public.can_manage_engineering());
create policy "ppm assignment manage" on public.ppm_assignments for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "ppm execution read" on public.ppm_execution_steps for select to authenticated
using (employee_id in (select id from public.employees where user_id=auth.uid()) or public.can_manage_engineering());
create policy "ppm execution insert" on public.ppm_execution_steps for insert to authenticated
with check (employee_id in (select id from public.employees where user_id=auth.uid()) or public.can_manage_engineering());
create policy "ppm execution update" on public.ppm_execution_steps for update to authenticated
using (employee_id in (select id from public.employees where user_id=auth.uid()) or public.can_manage_engineering())
with check (employee_id in (select id from public.employees where user_id=auth.uid()) or public.can_manage_engineering());

create or replace function public.complete_ppm_execution(p_execution_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare e public.ppm_execution_steps%rowtype;
begin
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;
 if e.employee_id is distinct from (select id from public.employees where user_id=auth.uid())
    and not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if coalesce(jsonb_array_length(e.checklist),0)=0 then raise exception 'CHECKLIST_REQUIRED'; end if;

 update public.ppm_execution_steps
 set completed_at=coalesce(completed_at,now()), qc_status=coalesce(qc_status,'PENDING')
 where id=p_execution_id;

 update public.ppm_schedule
 set status='COMPLETED'
 where id=e.ppm_schedule_id;

 return jsonb_build_object('ok',true,'execution_id',p_execution_id,'completed_at',now());
end $$;
