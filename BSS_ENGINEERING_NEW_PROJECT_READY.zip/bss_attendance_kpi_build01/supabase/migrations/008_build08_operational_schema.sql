
-- BUILD 08: Engineering operational schema
create extension if not exists pgcrypto;

create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  employee_no text unique not null,
  full_name text not null,
  email text,
  role public.app_role not null default 'TECHNICIAN',
  building_code text references public.buildings(code),
  department text default 'Engineering',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.equipment (
  id uuid primary key default gen_random_uuid(),
  asset_code text unique not null,
  building_code text not null references public.buildings(code),
  area text,
  equipment_type text not null,
  brand text,
  model text,
  serial_number text,
  capacity text,
  install_date date,
  criticality text not null default 'MEDIUM' check (criticality in ('LOW','MEDIUM','HIGH','CRITICAL')),
  status text not null default 'ACTIVE' check (status in ('ACTIVE','STANDBY','OUT_OF_SERVICE','RETIRED')),
  last_ppm_date date,
  next_ppm_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.ppm_schedule (
  id uuid primary key default gen_random_uuid(),
  equipment_id uuid not null references public.equipment(id) on delete cascade,
  scheduled_date date not null,
  frequency text not null default 'MONTHLY',
  assigned_to uuid references public.employees(id),
  status text not null default 'PLANNED' check (status in ('PLANNED','IN_PROGRESS','DONE','OVERDUE','CANCELLED')),
  completed_at timestamptz,
  result text,
  checklist_score numeric(5,2),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  ticket_no text unique not null,
  building_code text not null references public.buildings(code),
  equipment_id uuid references public.equipment(id),
  reported_by text,
  assigned_to uuid references public.employees(id),
  category text not null,
  severity text not null default 'MINOR' check (severity in ('MINOR','MEDIUM','MAJOR','CRITICAL')),
  status text not null default 'OPEN' check (status in ('OPEN','ASSIGNED','IN_PROGRESS','RESOLVED','CLOSED')),
  description text not null,
  reported_at timestamptz not null default now(),
  response_at timestamptz,
  resolved_at timestamptz,
  root_cause text,
  corrective_action text,
  is_repeat boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.work_orders (
  id uuid primary key default gen_random_uuid(),
  wo_no text unique not null,
  building_code text not null references public.buildings(code),
  equipment_id uuid references public.equipment(id),
  complaint_id uuid references public.complaints(id),
  assigned_to uuid references public.employees(id),
  wo_type text not null default 'CORRECTIVE',
  priority text not null default 'NORMAL' check (priority in ('LOW','NORMAL','HIGH','EMERGENCY')),
  status text not null default 'OPEN' check (status in ('OPEN','ASSIGNED','IN_PROGRESS','WAITING_PART','QC','DONE','CANCELLED')),
  description text not null,
  opened_at timestamptz not null default now(),
  started_at timestamptz,
  finished_at timestamptz,
  qc_score numeric(5,2),
  qc_notes text
);

create table if not exists public.ppm_checklist_items (
  id uuid primary key default gen_random_uuid(),
  ppm_id uuid not null references public.ppm_schedule(id) on delete cascade,
  item_name text not null,
  result text not null default 'OK' check (result in ('OK','NOT_OK','NA')),
  finding text,
  action text
);

create index if not exists idx_equipment_building on public.equipment(building_code);
create index if not exists idx_ppm_date on public.ppm_schedule(scheduled_date,status);
create index if not exists idx_complaints_building on public.complaints(building_code,status,severity);
create index if not exists idx_wo_building on public.work_orders(building_code,status);

alter table public.employees enable row level security;
alter table public.equipment enable row level security;
alter table public.ppm_schedule enable row level security;
alter table public.complaints enable row level security;
alter table public.work_orders enable row level security;
alter table public.ppm_checklist_items enable row level security;

create or replace function public.can_manage_engineering()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from public.profiles p
    where p.id=auth.uid() and p.active=true
      and p.role in ('SUPER_ADMIN','ADMIN','SUPERVISOR')
  )
$$;

create policy "authenticated read employees" on public.employees
for select to authenticated using (true);
create policy "managers manage employees" on public.employees
for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read equipment" on public.equipment
for select to authenticated using (true);
create policy "managers manage equipment" on public.equipment
for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read ppm" on public.ppm_schedule
for select to authenticated using (true);
create policy "managers manage ppm" on public.ppm_schedule
for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read complaints" on public.complaints
for select to authenticated using (true);
create policy "authenticated create complaints" on public.complaints
for insert to authenticated with check (true);
create policy "managers update complaints" on public.complaints
for update to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read workorders" on public.work_orders
for select to authenticated using (true);
create policy "managers manage workorders" on public.work_orders
for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

create policy "authenticated read checklist" on public.ppm_checklist_items
for select to authenticated using (true);
create policy "managers manage checklist" on public.ppm_checklist_items
for all to authenticated using (public.can_manage_engineering()) with check (public.can_manage_engineering());

-- Demo/master equipment examples: intentionally generic and easy to replace.
insert into public.equipment(asset_code,building_code,area,equipment_type,brand,criticality,status)
values
('PAL-AC-001','PAL','Lantai 1','AC Split','Daikin','MEDIUM','ACTIVE'),
('PAL-PNL-001','PAL','Ruang Panel','Electrical Panel','Schneider','CRITICAL','ACTIVE'),
('PEC-AC-001','PEC','Lantai 5','AC Split','Daikin','MEDIUM','ACTIVE'),
('SAN-PMP-001','SAN','Pump Room','Fire Pump','Ebara','CRITICAL','ACTIVE'),
('PH-GEN-001','PH','Genset Room','Generator Set','Cummins','CRITICAL','ACTIVE')
on conflict(asset_code) do nothing;
