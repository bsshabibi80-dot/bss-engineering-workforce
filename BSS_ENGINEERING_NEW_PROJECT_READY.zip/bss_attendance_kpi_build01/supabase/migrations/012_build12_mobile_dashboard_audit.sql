
-- BUILD 12: audit + reporting foundation
create table if not exists public.audit_events (
 id uuid primary key default gen_random_uuid(),
 actor_id uuid,
 action text not null,
 module text not null,
 record_id uuid,
 metadata jsonb default '{}'::jsonb,
 created_at timestamptz not null default now()
);
create index if not exists idx_audit_events_created on public.audit_events(created_at desc);
create index if not exists idx_audit_events_module on public.audit_events(module);
alter table public.audit_events enable row level security;
create policy "managers read audit" on public.audit_events for select to authenticated
using (public.can_manage_engineering());
create policy "authenticated insert audit" on public.audit_events for insert to authenticated
with check (true);

-- Prevent impossible KPI component values at DB level.
alter table public.kpi_monthly
  drop constraint if exists kpi_component_range;
alter table public.kpi_monthly
  add constraint kpi_component_range check (
    ppm_achievement between 0 and 100 and
    complaint_score between 0 and 100 and
    repeat_complaint_score between 0 and 100 and
    sla_score between 0 and 100 and
    availability_score between 0 and 100 and
    ppm_execution_score between 0 and 100 and
    complaint_impact_score between 0 and 100 and
    quality_repeat_job_score between 0 and 100 and
    response_resolution_score between 0 and 100 and
    attendance_discipline_score between 0 and 100 and
    safety_sop_score between 0 and 100
  );
