
-- BUILD 14: transactional PPM import
create or replace function public.import_ppm_batch(
 p_period_month date,
 p_file_name text,
 p_rows jsonb
) returns jsonb
language plpgsql security definer
set search_path=public
as $$
declare
 v_batch uuid;
 v_total int := jsonb_array_length(coalesce(p_rows,'[]'::jsonb));
 v_valid int := 0;
 v_error int := 0;
 v_dup int := 0;
 r jsonb;
 v_eq uuid;
 v_emp uuid;
begin
 if not public.can_manage_engineering() then
   raise exception 'NOT_AUTHORIZED';
 end if;

 insert into public.ppm_import_batches(period_month,file_name,imported_by,total_rows,status)
 values(date_trunc('month',p_period_month)::date,p_file_name,auth.uid(),v_total,'PROCESSING')
 returning id into v_batch;

 for r in select * from jsonb_array_elements(coalesce(p_rows,'[]'::jsonb)) loop
   begin
     select id into v_eq from public.equipment where equipment_code = r->>'equipment_id' limit 1;
     select id into v_emp from public.employees where lower(full_name)=lower(r->>'teknisi') limit 1;
     if v_eq is null or v_emp is null then
       v_error:=v_error+1;
       insert into public.ppm_import_rows(batch_id,row_number,ppm_date,building_code,equipment_code,equipment_name,location,ppm_type,frequency,technician_name,shift_name,status,target,notes,validation_status,validation_message)
       values(v_batch,(r->>'row')::int,(r->>'tanggal_ppm')::date,r->>'gedung',r->>'equipment_id',r->>'equipment_name',r->>'lokasi',r->>'jenis_ppm',r->>'frekuensi',r->>'teknisi',r->>'shift',r->>'status',coalesce(nullif(r->>'target','')::numeric,1),r->>'keterangan','ERROR','Equipment atau teknisi tidak ditemukan');
     else
       insert into public.ppm_import_rows(batch_id,row_number,ppm_date,building_code,equipment_code,equipment_name,location,ppm_type,frequency,technician_name,shift_name,status,target,notes,validation_status,validation_message)
       values(v_batch,(r->>'row')::int,(r->>'tanggal_ppm')::date,r->>'gedung',r->>'equipment_id',r->>'equipment_name',r->>'lokasi',r->>'jenis_ppm',r->>'frekuensi',r->>'teknisi',r->>'shift',r->>'status',coalesce(nullif(r->>'target','')::numeric,1),r->>'keterangan','READY','');
       v_valid:=v_valid+1;
     end if;
   exception when others then
     v_error:=v_error+1;
   end;
 end loop;

 update public.ppm_import_batches
 set valid_rows=v_valid,error_rows=v_error,duplicate_rows=v_dup,
     status=case when v_error=0 and v_valid=v_total then 'VALIDATED' else 'REVIEW' end
 where id=v_batch;

 return jsonb_build_object('batch_id',v_batch,'total',v_total,'valid',v_valid,'errors',v_error,'duplicates',v_dup);
end $$;
