
-- BUILD 19: Supervisor PPM dashboard, QC workflow, KPI refresh queue
create table if not exists public.kpi_refresh_queue(
 id uuid primary key default gen_random_uuid(),
 execution_id uuid,
 requested_at timestamptz not null default now(),
 processed_at timestamptz,
 status text not null default 'PENDING',
 error text
);
alter table public.kpi_refresh_queue enable row level security;
create policy "kpi refresh managers" on public.kpi_refresh_queue
for all to authenticated using(public.can_manage_engineering())
with check(public.can_manage_engineering());

create or replace function public.request_kpi_refresh(p_execution_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare q uuid;
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 insert into public.kpi_refresh_queue(execution_id) values(p_execution_id) returning id into q;
 return q;
end $$;

create or replace function public.approve_ppm_execution(p_execution_id uuid,p_qc_status text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare e public.ppm_execution_steps%rowtype; q uuid;
begin
 if not public.can_manage_engineering() then raise exception 'NOT_AUTHORIZED'; end if;
 if p_qc_status not in ('APPROVED','REJECTED') then raise exception 'INVALID_QC_STATUS'; end if;
 select * into e from public.ppm_execution_steps where id=p_execution_id for update;
 if e.id is null then raise exception 'EXECUTION_NOT_FOUND'; end if;
 update public.ppm_execution_steps
 set qc_status=p_qc_status,qc_by=auth.uid(),qc_at=now(),qc_note=p_note
 where id=p_execution_id;
 insert into public.ppm_audit_events(ppm_schedule_id,execution_id,action,actor_id,detail)
 values(e.ppm_schedule_id,e.id,'QC_'||p_qc_status,auth.uid(),jsonb_build_object('note',p_note));
 if p_qc_status='APPROVED' then
   insert into public.kpi_refresh_queue(execution_id) values(e.id);
 end if;
 return jsonb_build_object('ok',true,'execution_id',e.id,'qc_status',p_qc_status);
end $$;
