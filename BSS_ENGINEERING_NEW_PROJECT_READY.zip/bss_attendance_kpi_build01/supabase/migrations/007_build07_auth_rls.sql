create extension if not exists pgcrypto;

create type public.app_role as enum ('SUPER_ADMIN','ADMIN','SUPERVISOR','ENGINEER','TECHNICIAN');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text unique not null,
  role public.app_role not null default 'ENGINEER',
  building_code text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.buildings (
  code text primary key,
  name text not null,
  latitude double precision,
  longitude double precision,
  geofence_radius_m integer not null default 75,
  active boolean not null default true
);

insert into public.buildings(code,name) values
('PAL','Palmerah'),('PEC','Pecenongan'),('SAN','Sangaji'),('PH','Permata Hijau')
on conflict(code) do nothing;

-- Admin identity: create the auth user in Supabase Auth first, then assign SUPER_ADMIN.
-- Do not store passwords or service-role keys in frontend code.

alter table public.profiles enable row level security;
alter table public.buildings enable row level security;

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p
    where p.id=auth.uid() and p.role='SUPER_ADMIN' and p.active=true)
$$;

create policy "super admin full profiles" on public.profiles
for all using (public.is_super_admin()) with check (public.is_super_admin());

create policy "authenticated read buildings" on public.buildings
for select to authenticated using (true);

create policy "super admin manage buildings" on public.buildings
for all using (public.is_super_admin()) with check (public.is_super_admin());
