
-- BUILD 10: PPM + Complaint + Work Order operational flow
create table if not exists public.ppm_executions (
 id uuid primary key default gen_random_uuid(),
 ppm_schedule_id uuid references public.ppm_schedule(id),
 equipment_id uuid not null references public.equipment(id),
 employee_id uuid references public.employees(id),
 scheduled_date date not null default current_date,
 started_at timestamptz,
 completed_at timestamptz,
 status text not null default 'OPEN',
 finding text,
 action_taken text,
 root_cause text,
 recommendation text,
 before_photo_url text,
 after_photo_url text,
 qc_status text default 'PENDING',
 qc_by uuid references public.employees(id),
 qc_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.complaint_events (
 id uuid primary key default gen_random_uuid(),
 complaint_id uuid references public.complaints(id) on delete cascade,
 equipment_id uuid references public.equipment(id),
 reporter_id uuid references public.employees(id),
 assigned_employee_id uuid references public.employees(id),
 severity text not null default 'MINOR',
 title text not null,
 description text,
 reported_at timestamptz not null default now(),
 response_at timestamptz,
 resolved_at timestamptz,
 status text not null default 'OPEN',
 root_cause text,
 corrective_action text,
 repeat_flag boolean not null default false,
 repeat_of_complaint_id uuid references public.complaint_events(id),
 qc_status text default 'PENDING'
);

create table if not exists public.work_order_events (
 id uuid primary key default gen_random_uuid(),
 work_order_id uuid references public.work_orders(id) on delete cascade,
 equipment_id uuid references public.equipment(id),
 complaint_id uuid references public.complaint_events(id),
 ppm_execution_id uuid references public.ppm_executions(id),
 assigned_employee_id uuid references public.employees(id),
 priority text not null default 'NORMAL',
 status text not null default 'OPEN',
 description text,
 finding text,
 action_taken text,
 root_cause text,
 started_at timestamptz,
 completed_at timestamptz,
 qc_status text default 'PENDING',
 qc_by uuid references public.employees(id),
 qc_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.job_photos (
 id uuid primary key default gen_random_uuid(),
 ppm_execution_id uuid references public.ppm_executions(id) on delete cascade,
 complaint_id uuid references public.complaint_events(id) on delete cascade,
 work_order_event_id uuid references public.work_order_events(id) on delete cascade,
 photo_type text not null,
 storage_path text not null,
 caption text,
 created_at timestamptz not null default now()
);

create index if not exists idx_ppm_exec_equipment on public.ppm_executions(equipment_id,scheduled_date);
create index if not exists idx_complaint_equipment on public.complaint_events(equipment_id,reported_at);
create index if not exists idx_wo_equipment on public.work_order_events(equipment_id,created_at);

alter table public.ppm_executions enable row level security;
alter table public.complaint_events enable row level security;
alter table public.work_order_events enable row level security;
alter table public.job_photos enable row level security;

create policy "authenticated read ppm executions" on public.ppm_executions for select to authenticated using (true);
create policy "engineering manage ppm executions" on public.ppm_executions for all to authenticated
using (public.can_manage_engineering() or employee_id=auth.uid())
with check (public.can_manage_engineering() or employee_id=auth.uid());

create policy "authenticated read complaints events" on public.complaint_events for select to authenticated using (true);
create policy "authenticated manage complaints events" on public.complaint_events for all to authenticated
using (public.can_manage_engineering() or reporter_id=auth.uid() or assigned_employee_id=auth.uid())
with check (public.can_manage_engineering() or reporter_id=auth.uid() or assigned_employee_id=auth.uid());

create policy "authenticated read work order events" on public.work_order_events for select to authenticated using (true);
create policy "engineering manage work order events" on public.work_order_events for all to authenticated
using (public.can_manage_engineering() or assigned_employee_id=auth.uid())
with check (public.can_manage_engineering() or assigned_employee_id=auth.uid());

create policy "authenticated read job photos" on public.job_photos for select to authenticated using (true);
create policy "authenticated insert job photos" on public.job_photos for insert to authenticated with check (true);

-- Complaint severity points for KPI
create or replace function public.complaint_severity_points(p_severity text)
returns integer language sql immutable as $$
 select case upper(p_severity)
 when 'MINOR' then 1 when 'MEDIUM' then 3 when 'MAJOR' then 7 when 'CRITICAL' then 15 else 0 end
$$;
