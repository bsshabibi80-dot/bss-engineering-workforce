# BUILD 11 — KPI ENGINE
KPI database and calculation functions are added.

Building KPI:
PPM 30%, Complaint 30%, Repeat Complaint 15%, SLA 15%, Availability 10%.

Employee KPI:
PPM Execution 25%, Complaint Impact 25%, Quality/Repeat Job 20%, Response/Resolution 10%, Attendance/Discipline 10%, Safety/SOP 10%.

The UI route /kpi provides a dashboard prototype. Production calculation should populate kpi_monthly from validated operational data.
