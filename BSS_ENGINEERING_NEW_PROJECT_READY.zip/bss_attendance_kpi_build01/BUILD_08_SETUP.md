# BUILD 08 — Master Equipment + Operational Workflow

## Yang ditambahkan
1. Master Employee
2. Master Equipment
3. PPM Schedule
4. PPM Checklist
5. Complaint
6. Work Order
7. Relasi Equipment → PPM → Complaint → WO → KPI
8. Supabase RLS starter
9. Login via Supabase magic link
10. Realtime equipment update starter
11. Demo equipment untuk 4 gedung

## Jalur uji
- `/login` — login
- `/operations` — master equipment

## Admin
`bsshabibi80@gmail.com` harus dibuat di Supabase Authentication.
Set profile-nya menjadi `SUPER_ADMIN`.

## Penting
Data demo equipment hanya contoh. Ganti dengan master equipment aktual setiap gedung.

## Berikutnya
BUILD 09:
- Check-in/out QR + GPS server validation
- Dynamic QR
- Attendance realtime
- Upload foto
- PPM mobile form
- Complaint mobile form
- WO assignment
- Audit log
