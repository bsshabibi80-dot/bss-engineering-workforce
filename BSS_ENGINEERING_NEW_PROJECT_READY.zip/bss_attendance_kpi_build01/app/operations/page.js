'use client';

import { useEffect, useState } from 'react';
import { supabaseBrowser } from '../../lib/supabase-browser';

const demoEquipment = [
 {asset_code:'PAL-AC-001',building_code:'PAL',area:'Lantai 1',equipment_type:'AC Split',brand:'Daikin',criticality:'MEDIUM',status:'ACTIVE'},
 {asset_code:'PAL-PNL-001',building_code:'PAL',area:'Ruang Panel',equipment_type:'Electrical Panel',brand:'Schneider',criticality:'CRITICAL',status:'ACTIVE'},
 {asset_code:'PEC-AC-001',building_code:'PEC',area:'Lantai 5',equipment_type:'AC Split',brand:'Daikin',criticality:'MEDIUM',status:'ACTIVE'},
 {asset_code:'SAN-PMP-001',building_code:'SAN',area:'Pump Room',equipment_type:'Fire Pump',brand:'Ebara',criticality:'CRITICAL',status:'ACTIVE'},
 {asset_code:'PH-GEN-001',building_code:'PH',area:'Genset Room',equipment_type:'Generator Set',brand:'Cummins',criticality:'CRITICAL',status:'ACTIVE'}
];

export default function Operations() {
 const [items,setItems]=useState(demoEquipment);
 const [connected,setConnected]=useState(false);
 const [filter,setFilter]=useState('ALL');

 useEffect(()=>{
   if(!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) return;
   const sb=supabaseBrowser();
   sb.from('equipment').select('*').order('asset_code').then(({data})=>{
     if(data?.length) setItems(data);
     setConnected(true);
   });
   const ch=sb.channel('equipment-live').on('postgres_changes',{event:'*',schema:'public',table:'equipment'},()=>{
     sb.from('equipment').select('*').order('asset_code').then(({data})=>data?.length&&setItems(data));
   }).subscribe();
   return ()=>sb.removeChannel(ch);
 },[]);

 const shown=items.filter(x=>filter==='ALL'||x.building_code===filter);
 return <div style={{padding:24,fontFamily:'system-ui',background:'#f3f7fb',minHeight:'100vh',color:'#12244a'}}>
  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:'#fff',padding:18,borderRadius:14,border:'1px solid #dce7f2'}}>
   <div><h1 style={{margin:0}}>Master Equipment</h1><small>PPM • Complaint • WO • KPI</small></div>
   <b style={{color:connected?'#16a36a':'#65758b'}}>{connected?'● Realtime Connected':'○ Demo / Offline'}</b>
  </div>
  <div style={{display:'flex',gap:8,margin:'14px 0',flexWrap:'wrap'}}>
   {['ALL','PAL','PEC','SAN','PH'].map(x=><button key={x} onClick={()=>setFilter(x)} style={{padding:'9px 14px',borderRadius:9,border:'1px solid #cbdbea',background:filter===x?'#0b67d1':'#fff',color:filter===x?'#fff':'#12244a'}}>{x}</button>)}
  </div>
  <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(250px,1fr))',gap:12}}>
   {shown.map(x=><div key={x.asset_code} style={{background:'#fff',border:'1px solid #dce7f2',borderRadius:13,padding:16}}>
    <b style={{color:'#0b67d1'}}>{x.asset_code}</b><h3 style={{margin:'7px 0'}}>{x.equipment_type}</h3>
    <div>{x.brand||'-'} • {x.area||'-'}</div>
    <p style={{fontSize:13,color:'#65758b'}}>Gedung: {x.building_code}</p>
    <span style={{padding:'4px 8px',borderRadius:7,background:x.criticality==='CRITICAL'?'#ffe8e8':'#fff3db',color:x.criticality==='CRITICAL'?'#b62222':'#a96300',fontSize:12}}>{x.criticality}</span>
    <span style={{marginLeft:6,padding:'4px 8px',borderRadius:7,background:'#e9f8f0',color:'#08784e',fontSize:12}}>{x.status}</span>
   </div>)}
  </div>
  <div style={{marginTop:18,background:'#eaf5ff',padding:16,borderRadius:12}}>
   <b>Alur data BUILD 08:</b> Equipment → PPM Schedule → Checklist → Complaint/Breakdown → Work Order → QC → KPI.
  </div>
 </div>
}
