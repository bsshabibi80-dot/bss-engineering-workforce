'use client';
import {useEffect,useState} from 'react';
import {supabase} from '../../lib/supabase-browser';
import {exportCSV} from '../../lib/report-export';
export default function Reports(){
 const [rows,setRows]=useState([]),[type,setType]=useState('ppm'),[busy,setBusy]=useState(false);
 async function load(){
  setBusy(true);
  const table=type==='ppm'?'ppm_execution_steps':type==='attendance'?'attendance':'complaints';
  const {data,error}=await supabase.from(table).select('*').limit(500).order('created_at',{ascending:false});
  if(!error)setRows(data||[]); else alert(error.message);
  setBusy(false);
 }
 useEffect(()=>{load()},[type]);
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:1100,margin:'auto'}}>
   <h1>📄 BSS Engineering Reports</h1>
   <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:12}}>
    {['ppm','attendance','complaints'].map(x=><button key={x} onClick={()=>setType(x)} style={{padding:10,borderRadius:9,border:'1px solid #ccd6e2',background:type===x?'#17385f':'#fff',color:type===x?'#fff':'#17385f'}}>{x.toUpperCase()}</button>)}
    <button disabled={!rows.length} onClick={()=>exportCSV(rows,`BSS_${type}_report.csv`)} style={{padding:10,border:0,borderRadius:9,background:'#16834b',color:'#fff',fontWeight:800}}>⬇ Export CSV</button>
   </div>
   <div style={{background:'#fff',borderRadius:12,padding:10,overflow:'auto'}}>{busy?'Loading...':<pre style={{fontSize:11}}>{JSON.stringify(rows.slice(0,30),null,2)}</pre>}</div>
  </div>
 </main>
