'use client';
import {useState} from 'react';
import {distanceMeters,gpsQuality} from '../../lib/geofence';

const sites={
 PAL:{name:'Palmerah',lat:-6.20,lng:106.79,radius:75},
 PEC:{name:'Pecenongan',lat:-6.16,lng:106.83,radius:75},
 SAN:{name:'Sangaji',lat:-6.18,lng:106.82,radius:75},
 PH:{name:'Permata Hijau',lat:-6.23,lng:106.78,radius:75}
};

export default function Attendance(){
 const [building,setBuilding]=useState('PAL');
 const [status,setStatus]=useState('Belum melakukan validasi');
 const [detail,setDetail]=useState('');
 const [loading,setLoading]=useState(false);

 function validate(){
  setLoading(true);setStatus('Mengambil GPS...');
  if(!navigator.geolocation){setStatus('GPS tidak tersedia');setLoading(false);return}
  navigator.geolocation.getCurrentPosition(pos=>{
   const s=sites[building], a=pos.coords.accuracy;
   const d=distanceMeters(pos.coords.latitude,pos.coords.longitude,s.lat,s.lng);
   const ok=a<=100 && d<=s.radius;
   setStatus(ok?'CHECK-IN VALID':'CHECK-IN DITOLAK');
   setDetail(`Akurasi GPS ${a.toFixed(1)} m (${gpsQuality(a)}). Jarak ${d.toFixed(1)} m dari ${s.name}. Radius ${s.radius} m. Waktu perangkat tidak dipakai sebagai sumber kebenaran.`);
   setLoading(false);
  },err=>{setStatus('GPS gagal');setDetail(err.message);setLoading(false)},{enableHighAccuracy:true,timeout:15000,maximumAge:0});
 }
 return <main style={{minHeight:'100vh',background:'#eaf5ff',fontFamily:'system-ui',padding:18,color:'#12244a'}}>
  <div style={{maxWidth:520,margin:'auto',background:'#fff',padding:22,borderRadius:18,boxShadow:'0 8px 30px #0b4ea222'}}>
   <h1>Attendance • QR + GPS</h1>
   <p style={{color:'#65758b'}}>Prototype validasi lokasi. Produksi menggunakan QR dinamis dan validasi server.</p>
   <label>Gedung<select value={building} onChange={e=>setBuilding(e.target.value)} style={{display:'block',width:'100%',padding:12,marginTop:6}}>
    {Object.entries(sites).map(([k,v])=><option key={k} value={k}>{v.name}</option>)}
   </select></label>
   <div style={{margin:'16px 0',padding:15,background:'#eaf5ff',borderRadius:12}}>
    <b>1. Scan QR Gedung</b><br/><small>QR dinamis harus cocok dengan gedung dan masa berlaku.</small><br/><br/>
    <b>2. Ambil GPS</b><br/><small>High accuracy + akurasi maksimum 100 m.</small><br/><br/>
    <b>3. Validasi Server</b><br/><small>Server timestamp + geofence + duplicate check + shift.</small>
   </div>
   <button disabled={loading} onClick={validate} style={{width:'100%',padding:13,border:0,borderRadius:10,background:'#0b67d1',color:'#fff',fontWeight:800}}>{loading?'Validating...':'Simulasi Scan QR + Check In'}</button>
   <h2 style={{marginBottom:5}}>{status}</h2><p>{detail}</p>
   <hr/><small>Build 09 • BSS ENGINEERING • BSS blue UI</small>
  </div>
 </main>
}
