'use client';

import { useEffect, useState } from 'react';
import { supabaseBrowser } from '../lib/supabase-browser';
import { buildingKpi, grade } from '../lib/kpi';

const buildings = [
  {name:'Palmerah', score:92.4},
  {name:'Pecenongan', score:87.1},
  {name:'Sangaji', score:74.2},
  {name:'Permata Hijau', score:93.8},
];

export default function Home() {
  const [live, setLive] = useState(false);
  useEffect(() => {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (!url || !key) return;
    const supabase = supabaseBrowser();
    const channel = supabase.channel('dashboard-live')
      .on('postgres_changes',{event:'*',schema:'public',table:'complaints'},()=>setLive(true))
      .on('postgres_changes',{event:'*',schema:'public',table:'ppm_schedule'},()=>setLive(true))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  return <div className="app">
    <aside className="side">
      <img className="logo" src="/bss-engineering-logo.png" alt="BSS Engineering"/>
      <nav className="nav">
        {['🏠 Dasbor Utama','👤 Absensi','📝 Work Order','📅 PPM','⚠️ Complaint','🧰 Equipment','📊 KPI','📄 Laporan','🗄️ Master Data','⚙️ Pengaturan','❓ Bantuan'].map((x,i)=><a key={x} className={i===0?'active':''} href="#">{x}</a>)}
      </nav>
      <div className="profile"><b>Habib Hanafi</b><br/><small>Engineer • 🟢 Online</small></div>
    </aside>
    <section className="main">
      <header className="top">
        <div><div className="hello">Selamat Pagi, Habib Hanafi 👋</div><div className="date">Dashboard BSS Engineering</div></div>
        <div>🔔 &nbsp; <b>Habib Hanafi</b> • Engineer</div>
      </header>
      <main className="content">
        <section className="hero"><img src="/bss-engineering-logo.png" alt="BSS Engineering"/>
          <div><h1>BSS ENGINEERING</h1><p>Electrical • Mechanical • Civil</p><p>Support & Maintenance</p><p><i>"Dibuat Oleh / Prepared By"</i> BSS Engineering</p><b>🛡 Safety First &nbsp; ⚙ Quality Work &nbsp; 🎯 On Time Delivery &nbsp; 👥 Team Work</b></div>
        </section>
        <section className="cards">
          {[
            ['PPM Achievement','97.2%','Target 95%'],
            ['Total Complaint','38','MTD • Minggu ini 8'],
            ['Breakdown','7','MTD • Minggu ini 2'],
            ['Repeat Complaint','4','MTD • Minggu ini 1'],
            ['SLA Response','95.4%','Target 90%'],
            ['SLA Resolution','93.1%','Target 90%']
          ].map(x=><div className="card" key={x[0]}><div className="label">{x[0]}</div><div className="value">{x[1]}</div><div className="sub">{x[2]}</div></div>)}
        </section>
        <section className="grid">
          <div className="panel"><h3>KPI GEDUNG</h3>{buildings.map(b=><div key={b.name}><div className="row"><span>{b.name}</span><b>{b.score}</b></div><div className="bar"><i style={{width:`${b.score}%`}}/></div>)}</div>
          <div className="panel"><h3>TREND COMPLAINT</h3><p>6 bulan terakhir</p><div style={{height:150,display:'flex',alignItems:'end',gap:12}}>{[90,78,67,54,47,58].map((h,i)=><i key={i} className="bar" style={{height:h,width:18,background:'#0b67d1'}}/> )}</div><p className="sub">Minor • Medium • Major • Critical</p></div>
          <div className="panel"><h3>TOP TEKNISI</h3>{[['Andi Wijaya',94.6],['Budi Santoso',92.1],['Dedi Kurniawan',90.3],['Rudi Hartono',87.7],['Anton Saputra',84.2]].map((x,i)=><div className="row" key={x[0]}><span>{i+1}. {x[0]}</span><b>{x[1]}</b></div>)}</div>
        </section>
        <section className="quick">
          {['▦ Check In','💬 Buat Complaint','📝 Work Order','📅 PPM Schedule','☑ Checklist','📷 Upload Foto','📈 KPI Pribadi'].map(x=><button key={x}>{x}<small> Akses cepat</small></button>)}
        </section>
        <p className="sub">Realtime channel: {live ? '● ada perubahan data baru' : 'menunggu koneksi Supabase'}</p>
      </main>
    </section>
  </div>;
}
