'use client';
import {useState} from 'react';
const tasks=[
 {id:'WO-26001',eq:'PAL-AC-001',title:'AC tidak dingin',priority:'HIGH',status:'ASSIGNED'},
 {id:'WO-26002',eq:'PEC-AC-001',title:'AC alarm',priority:'NORMAL',status:'OPEN'},
 {id:'WO-26003',eq:'SAN-PMP-001',title:'Pump vibration',priority:'HIGH',status:'IN PROGRESS'}
];
export default function WO(){
 const [items,setItems]=useState(tasks);
 const advance=id=>setItems(items.map(x=>x.id===id?{...x,status:x.status==='OPEN'?'IN PROGRESS':x.status==='IN PROGRESS'?'WAITING QC':'CLOSED'}:x));
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:18,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:700,margin:'auto'}}><h1>Work Order Mobile</h1><p>Complaint / PPM → Assignment → Execution → QC → Close</p>
  {items.map(x=><section key={x.id} style={{background:'#fff',padding:16,borderRadius:14,margin:'10px 0'}}>
   <b>{x.id}</b> • {x.eq}<h3>{x.title}</h3><small>Priority: {x.priority} • Status: {x.status}</small>
   <textarea placeholder="Finding / action / root cause" style={{width:'100%',minHeight:70,marginTop:10,padding:10}}/>
   <button onClick={()=>advance(x.id)} style={{marginTop:8,padding:11,border:0,borderRadius:9,background:'#0b67d1',color:'#fff'}}>Update Status</button>
  </section>)}</div>
 </main>
}
