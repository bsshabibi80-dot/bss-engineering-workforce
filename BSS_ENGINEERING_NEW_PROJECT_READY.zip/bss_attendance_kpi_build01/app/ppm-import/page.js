'use client';
import {useMemo,useState} from 'react';
import {readPPMXlsx, exportPPMXlsx, normalizePPMRow, PPM_HEADERS} from '../../lib/ppm-import';

const required=['tanggal_ppm','gedung','equipment_id','jenis_ppm','teknisi','status'];
const demo=[{tanggal_ppm:'2026-08-01',gedung:'PAL',equipment_id:'PAL-AC-001',equipment_name:'AC Split 1',lokasi:'Lt 3',jenis_ppm:'Preventive Maintenance',frekuensi:'Monthly',teknisi:'Andi Wijaya',shift:'Engineering Regular',status:'SCHEDULED',target:1,keterangan:'PPM AC Agustus'}];

function validate(rows){
 const seen=new Set();
 return rows.map((raw,i)=>{
  const r=normalizePPMRow(raw);
  const missing=required.filter(k=>!r[k]);
  const key=`${r.tanggal_ppm}|${r.equipment_id}`;
  let status='READY',message='Siap diimport';
  if(missing.length){status='ERROR';message='Kolom kosong: '+missing.join(', ')}
  else if(!/^\d{4}-\d{2}-\d{2}$/.test(String(r.tanggal_ppm))){status='ERROR';message='Tanggal harus YYYY-MM-DD'}
  else if(!['PAL','PEC','SAN','PH'].includes(String(r.gedung).toUpperCase())){status='ERROR';message='Kode gedung harus PAL/PEC/SAN/PH'}
  else if(seen.has(key)){status='DUPLICATE';message='Duplikat tanggal + equipment dalam file'}
  seen.add(key);
  return {...r,row:i+2,validation_status:status,validation_message:message};
 });
}
export default function PPMImport(){
 const [rows,setRows]=useState([]),[file,setFile]=useState(''),[period,setPeriod]=useState('2026-08'),[mapping,setMapping]=useState(null),[busy,setBusy]=useState(false),[result,setResult]=useState(null);
 const checked=useMemo(()=>validate(rows),[rows]);
 const ready=checked.filter(x=>x.validation_status==='READY'), bad=checked.filter(x=>x.validation_status!=='READY');
 async function load(e){
  const f=e.target.files?.[0]; if(!f)return;
  setFile(f.name);
  try{const r=await readPPMXlsx(f);setRows(r.rows);setMapping(r)}catch(err){alert('File Excel tidak dapat dibaca. Pastikan format .xlsx/.xls benar.')}
 }
 function template(){
  exportPPMXlsx([demo[0]],'PPM_IMPORT_TEMPLATE.xlsx');
 }
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:1100,margin:'auto'}}>
   <section style={{background:'#fff',borderRadius:18,padding:18}}>
    <h1>📥 Import PPM Bulanan</h1>
    <p>Upload Excel PPM satu bulan. Histori bulan lain tetap aman.</p>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
     <label>Periode<input type="month" value={period} onChange={e=>setPeriod(e.target.value)} style={{display:'block',width:'100%',padding:11,marginTop:5}}/></label>
     <label>File Excel (.xlsx/.xls)<input type="file" accept=".xlsx,.xls" onChange={load} style={{display:'block',width:'100%',padding:8,marginTop:5}}/></label>
    </div>
    <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:12}}>
     <button onClick={template} style={{padding:11,border:0,borderRadius:9,background:'#17385f',color:'#fff'}}>Download Template Excel</button>
     {file&&<span style={{padding:11,background:'#eaf5ff',borderRadius:9}}>📄 {file}</span>}
    </div>
   </section>
   {rows.length>0&&<section style={{background:'#fff',borderRadius:18,padding:18,marginTop:12}}>
    <h2>Preview & Validasi</h2>{mapping&&<div style={{padding:10,background:'#f2f8ff',borderRadius:10,marginBottom:10}}><b>Mapping kolom otomatis:</b> {mapping.mapped.join(', ')||'Tidak ada kolom yang dikenali'}</div>}
    <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:12}}>
     <b>Total {checked.length}</b><b style={{color:'green'}}>READY {ready.length}</b><b style={{color:'red'}}>ERROR/DUPLICATE {bad.length}</b>
    </div>
    <div style={{overflowX:'auto'}}>
     <table style={{minWidth:950,width:'100%',borderCollapse:'collapse'}}><thead><tr>{['Row','Tanggal','Gedung','Equipment','Teknisi','Status','Validasi'].map(h=><th key={h} style={{padding:8,background:'#eaf5ff',textAlign:'left'}}>{h}</th>)}</tr></thead>
     <tbody>{checked.slice(0,300).map(r=><tr key={r.row}><td>{r.row}</td><td>{String(r.tanggal_ppm)}</td><td>{r.gedung}</td><td>{r.equipment_id}</td><td>{r.teknisi}</td><td>{r.status}</td><td>{r.validation_status}<br/><small>{r.validation_message}</small></td></tr>)}</tbody></table>
    </div>
    {checked.length>300&&<p>Preview menampilkan 300 baris pertama. Semua baris tetap diproses.</p>}
    <button disabled={!ready.length||bad.length>0||busy} onClick={async()=>{setBusy(true);setTimeout(()=>{setResult({ok:ready.length,error:bad.length});setBusy(false)},500)}} style={{marginTop:14,width:'100%',padding:15,border:0,borderRadius:10,background:(!ready.length||bad.length)?'#b7c2ce':'#0b67d1',color:'#fff',fontWeight:800}}>{busy?'Memproses...':`Konfirmasi Import ${ready.length} Baris`}</button>{result&&<div style={{marginTop:12,padding:12,background:'#eaf8ef',borderRadius:10}}>Batch siap diproses: <b>{result.ok}</b> baris valid, <b>{result.error}</b> baris ditolak. Hubungkan RPC Supabase saat deployment untuk commit database.</div>}
    <p style={{fontSize:12,opacity:.7}}>Catatan: tombol konfirmasi menjadi transaksi Supabase pada tahap deployment/production.</p>
   </section>}
  </div>
 </main>
