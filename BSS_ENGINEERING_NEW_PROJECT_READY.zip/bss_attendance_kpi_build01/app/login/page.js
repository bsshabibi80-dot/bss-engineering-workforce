'use client';
import { useState } from 'react';
import { supabaseBrowser } from '../../lib/supabase-browser';

export default function Login(){
 const [email,setEmail]=useState(''); const [sent,setSent]=useState(false); const [error,setError]=useState('');
 async function submit(e){
  e.preventDefault(); setError('');
  if(!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY){
    setError('Supabase belum dikonfigurasi. Isi .env.local terlebih dahulu.'); return;
  }
  const sb=supabaseBrowser();
  const {error}=await sb.auth.signInWithOtp({email,options:{emailRedirectTo:window.location.origin}});
  if(error)setError(error.message); else setSent(true);
 }
 return <main style={{minHeight:'100vh',display:'grid',placeItems:'center',background:'#eaf5ff',fontFamily:'system-ui'}}>
  <form onSubmit={submit} style={{width:'min(420px,92vw)',background:'#fff',padding:28,borderRadius:18,boxShadow:'0 8px 30px #0b4ea222'}}>
   <img src="/bss-engineering-logo.png" style={{width:130,height:130,objectFit:'contain',display:'block',margin:'0 auto'}}/>
   <h2 style={{textAlign:'center',color:'#0b4ea2'}}>BSS Engineering</h2>
   <p style={{textAlign:'center',color:'#65758b'}}>Login menggunakan email. Admin utama: bsshabibi80@gmail.com</p>
   <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email pengguna" type="email" required style={{width:'100%',padding:12,border:'1px solid #cbdbea',borderRadius:9}}/>
   <button style={{width:'100%',marginTop:12,padding:12,border:0,borderRadius:9,background:'#0b67d1',color:'#fff',fontWeight:700}}>Kirim Link Login</button>
   {sent&&<p style={{color:'#08784e'}}>Link login sudah dikirim ke email.</p>}
   {error&&<p style={{color:'#b62222'}}>{error}</p>}
  </form>
 </main>
}
