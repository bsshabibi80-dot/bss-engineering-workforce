'use client';
import {useState} from 'react';
const buildings=[
 {n:'Palmerah',score:92.4,ppm:97,complaint:91,repeat:94,sla:95,avail:94},
 {n:'Pecenongan',score:87.1,ppm:94,complaint:84,repeat:88,sla:89,avail:92},
 {n:'Sangaji',score:74.2,ppm:86,complaint:68,repeat:70,sla:76,avail:80},
 {n:'Permata Hijau',score:93.8,ppm:98,complaint:94,repeat:92,sla:96,avail:95}
];
const tech=[
 ['Andi Wijaya',94.6],['Budi Santoso',92.1],['Dedi Kurniawan',90.3],['Rudi Hartono',87.7],['Anton Saputra',84.2]
];
export default function KPI(){
 const [mode,setMode]=useState('building');
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:18,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:1000,margin:'auto'}}>
   <h1>KPI Engineering</h1><p>PPM • Complaint • Repeat • SLA • Attendance • Quality • Safety</p>
   <div style={{display:'flex',gap:8,margin:'15px 0'}}><button onClick={()=>setMode('building')} style={{padding:11}}>KPI Gedung</button><button onClick={()=>setMode('employee')} style={{padding:11}}>KPI Karyawan</button></div>
   {mode==='building'?<div style={{display:'grid',gap:12}}>
    {buildings.map(b=><section key={b.n} style={{background:'#fff',padding:18,borderRadius:16}}>
     <div style={{display:'flex',justifyContent:'space-between'}}><h2>{b.n}</h2><strong style={{fontSize:28}}>{b.score}</strong></div>
     <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:7}}>
      {[['PPM',b.ppm],['Complaint',b.complaint],['Repeat',b.repeat],['SLA',b.sla],['Availability',b.avail]].map(x=><div key={x[0]} style={{padding:9,background:'#eaf5ff',borderRadius:9}}><small>{x[0]}</small><br/><b>{x[1]}%</b></div>)}
     </div>
    </section>)}
   </div>:<section style={{background:'#fff',padding:18,borderRadius:16}}>
    <h2>Top Teknisi</h2>{tech.map((t,i)=><div key={t[0]} style={{display:'flex',justifyContent:'space-between',padding:13,borderBottom:'1px solid #e5edf5'}}><span>#{i+1} {t[0]}</span><b>{t[1]}</b></div>)}
   </section>}
   <section style={{background:'#fff',padding:18,borderRadius:16,marginTop:15}}>
    <h2>Bobot KPI</h2>
    <p><b>Gedung:</b> PPM 30% • Complaint 30% • Repeat 15% • SLA 15% • Availability 10%</p>
    <p><b>Karyawan:</b> PPM Execution 25% • Complaint Impact 25% • Quality/Repeat 20% • Response 10% • Attendance 10% • Safety 10%</p>
   </section>
  </div>
 </main>
