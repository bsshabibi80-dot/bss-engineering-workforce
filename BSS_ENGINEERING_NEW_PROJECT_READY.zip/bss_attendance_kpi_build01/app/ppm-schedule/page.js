'use client';
import {useEffect,useState} from 'react';
import {supabase} from '../../lib/supabase-browser';
export default function PPMSchedule(){
 const [rows,setRows]=useState([]),[loading,setLoading]=useState(true);
 async function load(){
  setLoading(true);
  const {data,error}=await supabase.from('ppm_schedule')
   .select('id,equipment_id,scheduled_date,frequency,assigned_to,status,completed_at,notes')
   .order('scheduled_date',{ascending:true}).limit(100);
  if(!error)setRows(data||[]); else alert(error.message);
  setLoading(false);
 }
 useEffect(()=>{load()},[]);
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:1000,margin:'auto'}}><h1>📅 PPM Schedule</h1><p>Monitoring jadwal, assignment, execution dan status QC.</p>
   {loading?<p>Loading...</p>:rows.map(r=><div key={r.id} style={{background:'#fff',borderRadius:12,padding:14,marginTop:9}}>
    <b>Equipment: {r.equipment_id}</b><br/><small>Tanggal: {r.scheduled_date} · Frekuensi: {r.frequency}</small><br/>
    <small>Status: <b>{r.status}</b> · Assigned: {r.assigned_to||'-'}</small>
   </div>)}
  </div>
 </main>
