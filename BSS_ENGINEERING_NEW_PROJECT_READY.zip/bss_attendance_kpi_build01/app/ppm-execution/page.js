'use client';
import {useState} from 'react';
import {supabase} from '../../lib/supabase-browser';
import {uploadPPMPhoto} from '../../lib/ppm-storage';

const checks=['Visual condition','Cleaning','Electrical/mechanical connection','Operating test','Safety/label'];
export default function PPMExecution(){
 const [scheduleId,setScheduleId]=useState(''),[executionId,setExecutionId]=useState('');
 const [done,setDone]=useState([]),[finding,setFinding]=useState(''),[action,setAction]=useState('');
 const [photos,setPhotos]=useState([]),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
 const toggle=x=>setDone(d=>d.includes(x)?d.filter(a=>a!==x):[...d,x]);
 async function start(){
  if(!scheduleId){setMessage('Masukkan PPM Schedule ID.');return}
  setBusy(true);
  const {data,error}=await supabase.rpc('start_ppm_execution',{p_schedule_id:scheduleId});
  if(error)setMessage(error.message);else{setExecutionId(data);setMessage('PPM dimulai.')}
  setBusy(false);
 }
 async function save(){
  if(!executionId){setMessage('Mulai PPM terlebih dahulu.');return}
  if(done.length<checks.length){setMessage('Checklist belum lengkap.');return}
  setBusy(true);
  try{
   const checklist=checks.map(x=>({item:x,checked:done.includes(x)}));
   const {error:upErr}=await supabase.from('ppm_execution_steps').update({checklist,findings:finding,corrective_action:action}).eq('id',executionId);
   if(upErr)throw upErr;
   for(const f of photos) await uploadPPMPhoto(supabase,f,executionId,'AFTER');
   const {data,error}=await supabase.rpc('complete_ppm_execution',{p_execution_id:executionId});
   if(error)throw error;
   setMessage(`PPM selesai. Execution: ${data.execution_id}. Menunggu QC.`);
  }catch(e){setMessage(e.message)}
  setBusy(false);
 }
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:650,margin:'auto',background:'#fff',borderRadius:18,padding:18}}>
   <h1>🔧 PPM Execution</h1>
   <label>PPM Schedule ID<input value={scheduleId} onChange={e=>setScheduleId(e.target.value)} placeholder="UUID dari PPM Schedule" style={{width:'100%',padding:11,marginTop:5}}/></label>
   <button onClick={start} disabled={busy} style={{width:'100%',padding:13,marginTop:9,border:0,borderRadius:10,background:'#17385f',color:'#fff',fontWeight:800}}>▶ Mulai PPM</button>
   {executionId&&<div style={{marginTop:10,padding:10,background:'#eaf8ef',borderRadius:10}}>Execution ID: {executionId}</div>}
   <h3>Checklist</h3>
   {checks.map(x=><label key={x} style={{display:'flex',gap:10,padding:13,borderBottom:'1px solid #eee'}}><input type="checkbox" checked={done.includes(x)} onChange={()=>toggle(x)} style={{width:22,height:22}}/>{x}</label>)}
   <label style={{display:'block',marginTop:14}}>Temuan<textarea value={finding} onChange={e=>setFinding(e.target.value)} style={{width:'100%',minHeight:75,padding:10}}/></label>
   <label style={{display:'block',marginTop:12}}>Tindakan<textarea value={action} onChange={e=>setAction(e.target.value)} style={{width:'100%',minHeight:75,padding:10}}/></label>
   <label style={{display:'block',marginTop:12}}>📷 Foto<input type="file" accept="image/*" capture="environment" multiple onChange={e=>setPhotos([...e.target.files])} style={{display:'block',marginTop:6}}/></label>
   <button onClick={save} disabled={busy||!executionId} style={{width:'100%',padding:15,marginTop:16,border:0,borderRadius:10,background:busy?'#b7c2ce':'#0b67d1',color:'#fff',fontWeight:800}}>{busy?'Memproses...':'Simpan & Complete PPM'}</button>
   {message&&<div style={{marginTop:12,padding:10,background:'#f2f8ff',borderRadius:10}}>{message}</div>}
  </div>
 </main>
