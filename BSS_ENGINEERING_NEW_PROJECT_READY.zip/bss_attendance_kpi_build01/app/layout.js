import './globals.css';

export const metadata = {
  title: 'BSS Engineering Attendance & KPI',
  description: 'PPM, Complaint, Equipment and Engineering KPI'
};

export default function RootLayout({ children }) {
  return <html lang="id"><body>{children}</body></html>;
}
