'use client';
import {useEffect,useState} from 'react';
import {supabase} from '../../lib/supabase-browser';
export default function PPMQC(){
 const [rows,setRows]=useState([]),[note,setNote]=useState(''),[busy,setBusy]=useState('');
 async function load(){
  const {data,error}=await supabase.from('ppm_execution_steps')
   .select('id,ppm_schedule_id,employee_id,started_at,completed_at,qc_status,findings,corrective_action')
   .order('completed_at',{ascending:false}).limit(50);
  if(!error)setRows(data||[]);
 }
 useEffect(()=>{load()},[]);
 async function qc(id,status){
  setBusy(id+status);
  const {error}=await supabase.rpc('approve_ppm_execution',{p_execution_id:id,p_qc_status:status,p_note:note});
  setBusy('');
  if(error) alert(error.message); else {setNote('');load();}
 }
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:900,margin:'auto'}}>
   <h1>🔍 PPM QC Supervisor</h1>
   <p>Review pekerjaan selesai sebelum masuk KPI.</p>
   <input value={note} onChange={e=>setNote(e.target.value)} placeholder="Catatan QC untuk approval/reject" style={{width:'100%',padding:12,borderRadius:10,border:'1px solid #ccd6e2'}}/>
   {rows.map(r=><article key={r.id} style={{background:'#fff',borderRadius:14,padding:15,marginTop:12,boxShadow:'0 2px 10px #dce8f2'}}>
    <b>Execution</b><div style={{fontSize:12,wordBreak:'break-all'}}>{r.id}</div>
    <div>Schedule: {r.ppm_schedule_id}</div>
    <div>Status QC: <b>{r.qc_status||'PENDING'}</b></div>
    <div style={{marginTop:8}}>Temuan: {r.findings||'-'}</div>
    <div>Tindakan: {r.corrective_action||'-'}</div>
    <div style={{display:'flex',gap:8,marginTop:12}}>
      <button disabled={!!busy} onClick={()=>qc(r.id,'APPROVED')} style={{flex:1,padding:12,border:0,borderRadius:9,background:'#16834b',color:'#fff',fontWeight:800}}>✓ APPROVE</button>
      <button disabled={!!busy} onClick={()=>qc(r.id,'REJECTED')} style={{flex:1,padding:12,border:0,borderRadius:9,background:'#b52b36',color:'#fff',fontWeight:800}}>✕ REJECT</button>
    </div>
   </article>)}
  </div>
 </main>
