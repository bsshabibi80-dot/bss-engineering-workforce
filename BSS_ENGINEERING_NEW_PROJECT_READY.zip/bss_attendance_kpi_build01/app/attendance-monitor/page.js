'use client';
import {useEffect,useState} from 'react';
import {supabaseBrowser} from '../../lib/supabase-browser';
export default function Monitor(){
 const [rows,setRows]=useState([]);
 useEffect(()=>{
  if(!process.env.NEXT_PUBLIC_SUPABASE_URL||!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)return;
  const sb=supabaseBrowser();
  const load=()=>sb.from('attendance').select('*, employees(full_name,employee_no)').order('check_in_at',{ascending:false}).limit(50).then(({data})=>data&&setRows(data));
  load();
  const ch=sb.channel('attendance-live').on('postgres_changes',{event:'*',schema:'public',table:'attendance'},load).subscribe();
  return()=>sb.removeChannel(ch);
 },[]);
 return <main style={{padding:20,fontFamily:'system-ui',background:'#f3f7fb',minHeight:'100vh',color:'#12244a'}}>
  <h1>Realtime Attendance</h1><p style={{color:'#65758b'}}>Supervisor/Admin monitoring • Check-in/out terbaru</p>
  <div style={{overflowX:'auto',background:'#fff',borderRadius:14,padding:10}}>
  <table style={{width:'100%',borderCollapse:'collapse'}}><thead><tr><th>Employee</th><th>Gedung</th><th>Check In</th><th>Check Out</th><th>Status</th><th>Validation</th></tr></thead>
  <tbody>{rows.map(r=><tr key={r.id}><td>{r.employees?.full_name||r.employee_id}</td><td>{r.building_code}</td><td>{r.check_in_at||'-'}</td><td>{r.check_out_at||'-'}</td><td>{r.status}</td><td>{r.validation_status}</td></tr>)}</tbody></table>
  </div>
 </main>
}
