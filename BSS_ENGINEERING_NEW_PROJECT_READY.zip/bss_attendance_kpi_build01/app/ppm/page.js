'use client';
import {useState} from 'react';
const demo=[
 {code:'PAL-AC-001',name:'AC Split 1',building:'Palmerah',status:'SCHEDULED'},
 {code:'PAL-PNL-001',name:'Panel LVMDP',building:'Palmerah',status:'SCHEDULED'},
 {code:'PEC-AC-001',name:'AC Split 1',building:'Pecenongan',status:'OVERDUE'},
 {code:'SAN-PMP-001',name:'Transfer Pump',building:'Sangaji',status:'SCHEDULED'}
];
export default function PPM(){
 const [selected,setSelected]=useState(demo[0]); const [done,setDone]=useState(false);
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:18,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:650,margin:'auto'}}>
   <h1>PPM Mobile</h1><p>Equipment → PPM → Checklist → Finding → Action → QC → KPI</p>
   {demo.map(x=><button key={x.code} onClick={()=>setSelected(x)} style={{display:'block',width:'100%',textAlign:'left',padding:14,margin:'8px 0',borderRadius:12,border:'1px solid #d8e6f5',background:selected.code===x.code?'#d9edff':'#fff'}}>
    <b>{x.code}</b> — {x.name}<br/><small>{x.building} • {x.status}</small>
   </button>)}
   <section style={{background:'#fff',padding:18,borderRadius:16,marginTop:16}}>
    <h2>{selected.code}</h2>
    {['Visual inspection','Electrical / mechanical check','Cleaning / tightening','Safety & SOP'].map((x,i)=><label key={x} style={{display:'block',padding:10}}><input type="checkbox"/> {x}</label>)}
    <textarea placeholder="Finding / kondisi equipment" style={{width:'100%',minHeight:80,padding:10}}/>
    <textarea placeholder="Action / pekerjaan yang dilakukan" style={{width:'100%',minHeight:80,padding:10,marginTop:8}}/>
    <input type="file" accept="image/*" capture="environment" style={{margin:'12px 0'}}/>
    <button onClick={()=>setDone(true)} style={{width:'100%',padding:13,border:0,borderRadius:10,background:'#0b67d1',color:'#fff',fontWeight:800}}>Submit PPM</button>
    {done&&<p><b>✓ PPM tersimpan sebagai draft/menunggu QC.</b></p>}
   </section>
  </div>
 </main>
}
