'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {supabase} from '../../lib/supabase-browser';
export default function Management(){
 const [stats,setStats]=useState({schedule:0,completed:0,pending:0,approved:0,rejected:0});
 useEffect(()=>{(async()=>{
  const {data}=await supabase.from('ppm_execution_steps').select('id,qc_status,completed_at');
  const a=data||[]; setStats({schedule:a.length,completed:a.filter(x=>x.completed_at).length,pending:a.filter(x=>!x.qc_status||x.qc_status==='PENDING').length,approved:a.filter(x=>x.qc_status==='APPROVED').length,rejected:a.filter(x=>x.qc_status==='REJECTED').length});
 })()},[]);
 const cards=[['Execution',stats.schedule],['Completed',stats.completed],['QC Pending',stats.pending],['Approved',stats.approved],['Rejected',stats.rejected]];
 return <main style={{minHeight:'100vh',background:'#eef7ff',padding:14,fontFamily:'system-ui',color:'#10234b'}}>
  <div style={{maxWidth:1100,margin:'auto'}}><h1>🏢 BSS Engineering Management</h1>
   <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))',gap:10}}>{cards.map(c=><div key={c[0]} style={{background:'#fff',padding:18,borderRadius:14}}><small>{c[0]}</small><h2>{c[1]}</h2></div>)}</div>
   <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:12,marginTop:18}}>
    <Link href="/ppm-schedule" style={{background:'#17385f',color:'#fff',padding:18,borderRadius:12,textDecoration:'none'}}>📅 PPM Schedule</Link>
    <Link href="/ppm-qc" style={{background:'#0b67d1',color:'#fff',padding:18,borderRadius:12,textDecoration:'none'}}>🔍 QC Supervisor</Link>
    <Link href="/kpi" style={{background:'#16834b',color:'#fff',padding:18,borderRadius:12,textDecoration:'none'}}>📊 KPI</Link>
    <Link href="/reports" style={{background:'#6a4bb3',color:'#fff',padding:18,borderRadius:12,textDecoration:'none'}}>📄 Reports</Link>
   </div>
  </div>
 </main>
