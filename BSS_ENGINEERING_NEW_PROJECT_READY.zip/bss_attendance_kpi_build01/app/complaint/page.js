'use client';
import {useState} from 'react';
export default function Complaint(){
 const [severity,setSeverity]=useState('MINOR'); const [sent,setSent]=useState(false);
 const pts={MINOR:1,MEDIUM:3,MAJOR:7,CRITICAL:15};
 return <main style={{minHeight:'100vh',background:'#fff5f3',padding:18,fontFamily:'system-ui',color:'#3b1e1b'}}>
  <div style={{maxWidth:600,margin:'auto',background:'#fff',padding:20,borderRadius:16}}>
   <h1>Complaint / Gangguan</h1><p>Complaint otomatis terhubung ke Equipment, WO, teknisi, SLA dan KPI.</p>
   <input placeholder="Judul gangguan" style={{width:'100%',padding:12,marginBottom:8}}/>
   <select value={severity} onChange={e=>setSeverity(e.target.value)} style={{width:'100%',padding:12}}>
    {Object.keys(pts).map(x=><option key={x}>{x}</option>)}
   </select>
   <small>Bobot KPI: {pts[severity]} point</small>
   <textarea placeholder="Deskripsi gangguan / gejala" style={{width:'100%',minHeight:110,padding:12,marginTop:10}}/>
   <input type="file" accept="image/*" capture="environment" style={{margin:'12px 0'}}/>
   <button onClick={()=>setSent(true)} style={{width:'100%',padding:13,border:0,borderRadius:10,background:'#d64532',color:'#fff',fontWeight:800}}>Kirim Complaint</button>
   {sent&&<p><b>✓ Complaint dibuat — menunggu assignment teknisi.</b></p>}
  </div>
 </main>
}
