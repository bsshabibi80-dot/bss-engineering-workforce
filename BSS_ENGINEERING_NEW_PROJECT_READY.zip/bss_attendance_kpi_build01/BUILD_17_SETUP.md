# BUILD 17 — PRODUCTION PPM FOUNDATION

Added:
- equipment-specific checklist templates (AC, PANEL, PUMP, GENSET)
- ppm_execution_photos table
- QC approval RPC
- mobile camera/photo selection
- Supabase client hook in execution page

Production deployment checklist:
1. Create Storage bucket `ppm-photos` and apply storage policies.
2. Bind actual ppm_schedule/execution IDs to the execution page.
3. Upload photos with authenticated user.
4. Insert photo metadata.
5. Call complete_ppm_execution.
6. Supervisor calls approve_ppm_execution.
7. Recalculate KPI from approved PPM executions.
