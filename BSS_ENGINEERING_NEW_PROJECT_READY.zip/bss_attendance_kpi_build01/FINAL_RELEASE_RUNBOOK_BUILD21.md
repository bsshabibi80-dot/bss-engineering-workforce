# FINAL RELEASE RUNBOOK — BUILD 21

## What was fixed in preflight
1. Supabase client export mismatch fixed.
2. PPM completion status corrected from invalid `COMPLETED` to schema-valid `DONE`.
3. QC note column added.
4. PPM schedule UI aligned to actual schema.
5. Preflight test script added.

## Before team testing
1. Create Supabase project.
2. Apply migrations 007 through 021 in order.
3. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in Vercel.
4. Create Auth user for bsshabibi80@gmail.com and assign SUPER_ADMIN profile.
5. Enter real buildings and GPS coordinates.
6. Enter employees and link `employees.user_id` to Auth users.
7. Enter real equipment.
8. Import one small PPM Excel file.
9. Test: login -> PPM -> execution -> photo -> complete -> QC -> KPI.
10. Test attendance: QR -> GPS -> check-in -> checkout.
11. Test complaint -> WO -> QC -> KPI.
12. Run `node tools/preflight.js`.
13. Only after UAT approval share with team.

## Important
A public production URL cannot be created from this workspace because no Vercel/Supabase deployment credentials or deployment connector is available. The package is prepared for deployment, but it must be connected to your Vercel/Supabase accounts before a real public URL exists.
