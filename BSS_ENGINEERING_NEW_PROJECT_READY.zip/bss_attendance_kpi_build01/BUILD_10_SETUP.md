# BUILD 10
Operational mobile foundation for PPM, complaints and work orders.

Routes:
- /ppm
- /complaint
- /work-orders

Database migration 010 adds execution/event/photo records and complaint severity points.

Production next:
- connect forms to Supabase
- Supabase Storage for before/after photos
- technician assignment and notification
- QC approval
- SLA timer
- repeat complaint detection
- KPI calculation and realtime dashboard
