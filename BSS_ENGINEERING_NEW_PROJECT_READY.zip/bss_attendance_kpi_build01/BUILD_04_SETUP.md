# BUILD 04 — KPI ENGINE

Build 04 mengubah data absensi dan pekerjaan menjadi skor KPI teknisi.

## Bobot default
- Attendance: 20%
- Work Order / Productivity: 30%
- Quality: 25%
- Efficiency: 15%
- Safety / Discipline: 10%

## Grade
- 95–100: EXCELLENT
- 90–94.99: VERY GOOD
- 80–89.99: GOOD
- 70–79.99: NEED IMPROVEMENT
- <70: POOR

## Prinsip perhitungan
1. Attendance berasal dari valid attendance yang lolos QR + GPS + shift.
2. Work Order menggunakan work points, bukan sekadar jumlah WO.
3. Quality dipengaruhi QC, rework dan repeat job.
4. Efficiency membandingkan actual time dengan target time.
5. Safety/discipline berasal dari checklist pelanggaran, keterlambatan, kepatuhan SOP, dan catatan supervisor.
6. Final score dihitung server-side agar tidak bisa dimanipulasi dari browser.

## Catatan
Nilai target KPI perlu disesuaikan setelah data aktual 1–3 bulan terkumpul. Jangan langsung menjadikan target contoh sebagai target resmi.

## Berikutnya
BUILD 05 — Supervisor & Admin Dashboard: realtime manpower, attendance map/status, WO board, KPI ranking, repeat job, approval/QC, dan dashboard 4 gedung.
