# BUILD 06 — Dashboard Utama BSS Engineering

Dashboard utama sekarang mengikuti gambar referensi yang diberikan:
- Sidebar biru khas BSS
- Logo BSS Engineering
- Sapaan personil: Habib Hanafi
- Role: Engineer
- Hero banner BSS Engineering
- KPI cards: PPM, Complaint, Breakdown, Repeat Complaint, SLA
- KPI 4 gedung
- Trend complaint
- Top teknisi
- Quick action mobile-friendly
- Warna area matrik/card menggunakan putih + biru muda agar berbeda dari sidebar.

## Data pada screenshot
Angka dan nama teknisi di dashboard adalah DATA DEMO untuk prototype.
Build berikutnya akan mengambil data realtime dari Supabase sehingga tidak lagi hard-coded.

## Logo
`assets/bss-engineering-logo.png` diekstrak dari gambar referensi yang di-upload pengguna untuk keperluan prototype ini.

## Produksi
Build 07 akan menghubungkan:
Auth → Profiles/Roles → Supabase RLS → Realtime → Dashboard widgets → 4 building master → Attendance → PPM → Complaint → Equipment → KPI.

Admin `bsshabibi80@gmail.com` tetap SUPER_ADMIN.
