-- BUILD 04 — KPI ENGINE
-- Supabase/PostgreSQL starter calculation layer.
-- KPI weights: Attendance 20, Work Order 30, Quality 25, Efficiency 15, Safety/Discipline 10.

create table if not exists kpi_periods (
  id uuid primary key default gen_random_uuid(),
  period_start date not null,
  period_end date not null,
  name text not null,
  status text not null default 'OPEN',
  created_at timestamptz not null default now(),
  unique(period_start, period_end)
);

create table if not exists kpi_scores (
  id uuid primary key default gen_random_uuid(),
  period_id uuid not null references kpi_periods(id) on delete cascade,
  employee_id uuid not null,
  attendance_score numeric(5,2) not null default 0,
  work_order_score numeric(5,2) not null default 0,
  quality_score numeric(5,2) not null default 0,
  efficiency_score numeric(5,2) not null default 0,
  safety_discipline_score numeric(5,2) not null default 0,
  final_score numeric(5,2) generated always as (
    attendance_score * 0.20 +
    work_order_score * 0.30 +
    quality_score * 0.25 +
    efficiency_score * 0.15 +
    safety_discipline_score * 0.10
  ) stored,
  rank_no integer,
  grade text,
  notes text,
  calculated_at timestamptz not null default now(),
  unique(period_id, employee_id)
);

create index if not exists idx_kpi_period_score on kpi_scores(period_id, final_score desc);

-- Grade bands
create or replace function kpi_grade(score numeric)
returns text language sql immutable as $$
  select case
    when score >= 95 then 'EXCELLENT'
    when score >= 90 then 'VERY GOOD'
    when score >= 80 then 'GOOD'
    when score >= 70 then 'NEED IMPROVEMENT'
    else 'POOR'
  end
$$;

-- Example normalized work-order score:
-- completed points / target points * 100, capped at 100.
create or replace function kpi_normalize(actual numeric, target numeric)
returns numeric language sql immutable as $$
  select case when coalesce(target,0) <= 0 then 0
              else least(100, greatest(0, coalesce(actual,0) / target * 100))
         end
$$;

-- Repeat-job quality penalty example:
-- quality starts at 100, minus 10 points per repeat job, floor 0.
create or replace function kpi_quality_from_repeat(repeat_count integer)
returns numeric language sql immutable as $$
  select greatest(0, 100 - coalesce(repeat_count,0) * 10)
$$;
