# BUILD 02 — Dynamic QR + GPS + Geofence

## Production flow
1. User login.
2. Scan dynamic QR.
3. Server validates token and expiry.
4. Browser requests GPS.
5. Server receives GPS + accuracy.
6. Server calculates distance to the selected building.
7. Server validates shift and duplicate attendance.
8. Server writes check-in using server timestamp.
9. Check-out only after an active check-in.
10. Every attempt is recorded in audit logs.

## Anti-fraud
- Use short-lived signed QR tokens (60 seconds by default).
- Never trust client-calculated distance for the final decision.
- Never use the phone clock as the official attendance timestamp.
- Store GPS, accuracy, building, QR token id, user id, session/device id and result.
- Rate-limit repeated scan attempts.

## Important
Browser geolocation in production requires HTTPS. The actual server-side validation will be implemented in the Next.js/Supabase production build.

## Next build
BUILD 03: Work Order + Checklist + Photo evidence + Repeat Job detection.
