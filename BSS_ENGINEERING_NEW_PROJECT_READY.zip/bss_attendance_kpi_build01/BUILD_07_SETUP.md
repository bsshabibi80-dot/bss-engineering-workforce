# BUILD 07 — REAL APP STARTER

This build moves the project from UI prototype to a real Next.js + Supabase starter.

## Run
1. Install Node.js LTS.
2. Copy `.env.example` to `.env.local`.
3. Put the Supabase project URL and anon key in `.env.local`.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open the local address shown by Next.js.

## Supabase
Run `supabase/migrations/007_build07_auth_rls.sql` in the Supabase SQL editor.

Create the authentication account for:
`bsshabibi80@gmail.com`

Then create/update its profile row with role:
`SUPER_ADMIN`

Do NOT put the Supabase service-role key in the browser.

## Current state
- Build 06 dashboard design is retained.
- BSS logo is included.
- Dashboard has a Supabase Realtime subscription starter for complaints and PPM.
- Building master has the four BSS buildings.
- RLS starter protects profile administration and building administration.
- KPI calculation helpers are included.

## Not yet production complete
Authentication pages, all CRUD screens, server-side attendance validation, dynamic QR signing, storage upload policies, complete complaint/PPM/WO forms, and export engine still need to be wired in subsequent builds.

## Next
BUILD 08 — Login + role-based navigation + real CRUD for Employees, Buildings, Equipment, PPM, Complaint and Work Order.
