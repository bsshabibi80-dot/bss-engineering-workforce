# BUILD 12 — MOBILE FIRST + MANAGEMENT + REPORTING

Design priorities:
1. Mobile-first: usable with one hand, responsive cards, large touch controls.
2. GPS accuracy: high accuracy, fresh position, 20-second timeout, maximum 100 m accuracy.
3. Server remains authoritative for time and geofence.
4. Dynamic QR prevents static screenshot reuse.
5. Audit events record sensitive operational actions.
6. KPI components are constrained 0–100 in database.
7. Reporting Center supports building/period filtering and has Excel/PDF UI placeholders.

Important:
- Actual building coordinates must be configured in the database.
- Export buttons are UI placeholders until Build 13 connects real Excel/PDF generation.
