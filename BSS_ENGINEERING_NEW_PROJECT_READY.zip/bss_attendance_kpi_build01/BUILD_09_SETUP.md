# BUILD 09 — QR + GPS + GEOFENCE + REALTIME

## Production validation design
1. User authenticates.
2. App obtains current GPS with high accuracy.
3. User scans a short-lived/dynamic QR belonging to the selected building.
4. Server validates QR/building.
5. Server calculates distance using building coordinates and radius.
6. GPS accuracy must be acceptable.
7. Server timestamp is authoritative; device clock is not trusted.
8. Unique employee/date prevents duplicate attendance.
9. Attendance log stores validation result for audit.
10. Realtime dashboard subscribes to attendance changes.

## Important
Building latitude/longitude must be entered with the actual coordinates before production. The `/attendance` page uses clearly marked demo coordinates only.

## Routes
- `/attendance`
- `/attendance-monitor`

## Security
Do not expose Supabase service-role keys in the browser. Dynamic QR secrets should be generated/validated server-side; the included SQL provides the secure database foundation.
